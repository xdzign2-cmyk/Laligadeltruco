import { useState, useEffect } from 'react';
import { AreaChart, Area, Tooltip, ResponsiveContainer, XAxis, YAxis, CartesianGrid } from 'recharts';
import {
    Users, X, Edit2, Trash2, PlusCircle, User, Ship, Mountain, Lock, FileText, Upload, Plus,
    RefreshCw, Send, Landmark, Activity, Trophy, Medal, Calculator as CalcIcon, CircleDollarSign,
    TrendingUp, ChevronLeft, ChevronRight, ShieldAlert, CheckCircle2, Save
} from 'lucide-react';

const monthNames = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
import { supabase } from './lib/supabase';
import PublicityDashboard from './PublicityDashboard';
import NominaModule from './NominaModule';

// --- CONFIGURACIÓN & TYPES ---
const HOURS_PER_SHIFT = 9;   // Un turno dura 9 horas
const SHIFT_VALUE_USD = 9.6; // Un turno vale 9.6$ Dolares

// --- DATOS INICIALES POR DEFECTO ---


const defaultShipments = [
    { id: 1, fecha: '29/12', monto: 317000, nota: '' },
    { id: 2, fecha: '31/12', monto: 350000, nota: '' },
    { id: 3, fecha: '04/01', monto: 250000, nota: '' },
    { id: 4, fecha: '05/01', monto: 80000, nota: 'ADELANTO' },
    { id: 5, fecha: '06/01', monto: 200000, nota: '' },
    { id: 6, fecha: '08/01', monto: 330000, nota: '' },
    { id: 7, fecha: '09/01', monto: 210000, nota: '' },
    { id: 8, fecha: '10/01', monto: 189000, nota: '' },
];

const defaultBanks = [
    { id: 1, nombre: 'Banesco', monto: 150000 },
    { id: 2, nombre: 'Binance USDT', monto: 500000 },
    { id: 3, nombre: 'Efectivo Caja', monto: 25000 },
];

const defaultPlayers = [
    { id: 1, nombre: 'El Barco', saldo: 0, tipo: 'barco' },
    { id: 2, nombre: 'La Cueva', saldo: 0, tipo: 'cueva' },
];

// Ahora los empleados tienen GRUPO (Barco o Cueva)
const defaultEmployees = [
    { id: 1, name: 'Romero', email: 'romero@sistema.com', status: 'Activo', group: 'Barco', shift: 'Mañana' },
    { id: 2, name: 'Alfredo', email: 'alfredo@sistema.com', status: 'Activo', group: 'Barco', shift: 'Noche' },
    { id: 3, name: 'Francel', email: 'francel@sistema.com', status: 'Activo', group: 'Cueva', shift: 'Mañana' },
    { id: 4, name: 'Willy', email: 'willy@sistema.com', status: 'Activo', group: 'Cueva', shift: 'Noche' },
    { id: 5, name: 'Francis', email: 'francis@sistema.com', status: 'Activo', group: 'Barco', shift: 'Franquero' },
    { id: 6, name: 'Clemente', email: 'clemente@sistema.com', status: 'Activo', group: 'Cueva', shift: 'Franquero' },
];

const defaultShifts = {};

const Dashboard = ({ role = 'guest', userEmail, onLogout, onNavigateToRestriccion }: { role?: string, userEmail: string, onLogout: () => void, onNavigateToRestriccion?: () => void }) => {

    const [showPublicityAnalytics, setShowPublicityAnalytics] = useState(false);
    const isAdminOrVice = role === 'admin' || role === 'vicepresident';
    const isOnlyAdmin = role === 'admin';
    const [dashboardGroup, setDashboardGroup] = useState<'Barco' | 'Cueva' | 'Todos'>('Todos');


    // --- STATES & PERSISTENCE ---
    const loadState = (key: string, defaultValue: any) => {
        try {
            const saved = localStorage.getItem(key);
            return saved ? JSON.parse(saved) : defaultValue;
        } catch (e) {
            console.error(`Error loading ${key}, resetting to default.`, e);
            return defaultValue;
        }
    };

    // --- DYNAMIC PERIOD STATES ---
    const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
    const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
    const [viewMode, setViewMode] = useState<'Q1' | 'Q2'>(new Date().getDate() <= 15 ? 'Q1' : 'Q2');

    const [data, setData] = useState<any[]>([]);
    const [shipments, setShipments] = useState(() => loadState('shipmentsData', defaultShipments));
    const [banks, setBanks] = useState(() => loadState('banksData', defaultBanks));
    const [players, setPlayers] = useState(() => loadState('playersData', defaultPlayers));
    const [employees, setEmployees] = useState(() => loadState('employeesData', defaultEmployees));
    const [shiftsMatrix, setShiftsMatrix] = useState(() => loadState('shiftsMatrixData', defaultShifts));
    const [shiftsNotes, setShiftsNotes] = useState(() => loadState('shiftsNotesData', {})); // New State for Notes
    const [currentFortnight, setCurrentFortnight] = useState(1); // Keep for payroll compatibility

    // --- MASTERS VIEW STATE ---
    const [showMasterModal, setShowMasterModal] = useState(false);
    const [masterLogs, setMasterLogs] = useState<any[]>([]);
    const [selectedUserForReceipt, setSelectedUserForReceipt] = useState<string | null>(null);
    const [uploadUrl, setUploadUrl] = useState('');
    const [editingLog, setEditingLog] = useState<any>(null);

    // --- NEW: ONLINE USERS & APPROVALS STATES ---
    const [onlineUsers, setOnlineUsers] = useState<any[]>([]);
    const [pendingApprovals, setPendingApprovals] = useState<any[]>([]);
    const [includePublicityInTotal, setIncludePublicityInTotal] = useState(() => loadState('includePublicityInTotal', true));
    const [activeShiftDay, setActiveShiftDay] = useState<{ empId: string | number; day: number } | null>(null);
    const [shiftDetailForm, setShiftDetailForm] = useState({ entrada: '', salida: '', horas: '', estatus: 'Falta' });
    const [showNominaPage, setShowNominaPage] = useState(false);

    const loadOnlineUsers = async () => {
        if (!isAdminOrVice) return;
        const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
        const { data } = await supabase
            .from('gestor_sesiones')
            .select('*')
            .gt('last_active_at', fiveMinutesAgo);
        if (data) setOnlineUsers(data);
    };

    const handleKickUser = async (userEmailToKick: string, deviceId: string) => {
        if (!isOnlyAdmin) return;
        if (!confirm(`¿Cerrar sesión forzosamente a ${userEmailToKick}?`)) return;

        const { error } = await supabase
            .from('gestor_sesiones')
            .delete()
            .eq('user_email', userEmailToKick)
            .eq('device_id', deviceId);

        if (error) alert('Error al expulsar: ' + error.message);
        else loadOnlineUsers();
    };

    const loadPendingApprovals = async () => {
        if (!isOnlyAdmin) return;
        const { data } = await supabase
            .from('usuarios_sistema')
            .select('*')
            .eq('estado', 'pendiente');
        if (data) setPendingApprovals(data);
    };

    const handleApproveUser = async (id: string) => {
        const { error } = await supabase.from('usuarios_sistema').update({ estado: 'aprobado' }).eq('id', id);
        if (error) alert(error.message);
        else loadPendingApprovals();
    };

    const handleDenyUser = async (id: string) => {
        if (!confirm('¿Denegar acceso definitivamente?')) return;
        const { error } = await supabase.from('usuarios_sistema').update({ estado: 'denegado' }).eq('id', id);
        if (error) alert(error.message);
        else loadPendingApprovals();
    };

    useEffect(() => {
        if (isAdminOrVice) {
            loadOnlineUsers();
            const interval = setInterval(loadOnlineUsers, 10000);
            return () => clearInterval(interval);
        }
    }, [isAdminOrVice]);

    useEffect(() => {
        if (isOnlyAdmin) {
            loadPendingApprovals();
            const interval = setInterval(loadPendingApprovals, 15000);
            return () => clearInterval(interval);
        }
    }, [isOnlyAdmin]);

    const [pubMonth, setPubMonth] = useState(new Date().getMonth());
    const [pubYear, setPubYear] = useState(new Date().getFullYear());
    const [pubGridGroup, setPubGridGroup] = useState<'Barco' | 'Cueva' | 'Todos'>('Todos');

    const fetchPublicityData = async () => {
        const { data } = await supabase.from('publicidad_detallada').select('*');
        if (data) {
            const activeMap: any = {};
            data.forEach(d => {
                if (!activeMap[d.fecha]) activeMap[d.fecha] = { Barco: 0, Cueva: 0, Total: 0 };
                const grupo = d.grupo || 'Barco';
                activeMap[d.fecha][grupo] += Number(d.monto);
                activeMap[d.fecha].Total += Number(d.monto);
            });
            setPublicityActive(activeMap);
        }
    };

    useEffect(() => {
        fetchPublicityData();
        const channel = supabase
            .channel('publicity_sync_detailed')
            .on('postgres_changes', { event: '*', schema: 'public', table: 'publicidad_detallada' }, () => {
                fetchPublicityData();
            })
            .subscribe();
        return () => { supabase.removeChannel(channel); };
    }, []);

    const loadMasterLogs = async () => {
        const { data } = await supabase.from('registros_operativos').select('*').order('created_at', { ascending: false }).limit(50);
        if (data) setMasterLogs(data);
    };

    const handleDeleteMasterLog = async (id: string) => {
        if (!confirm('¿Eliminar registro?')) return;
        const { error } = await supabase.from('registros_operativos').delete().eq('id', id);
        if (error) alert(error.message);
        else loadMasterLogs();
    };

    const handleUpdateMasterLog = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!editingLog) return;
        const profit = (parseFloat(editingLog.monto_apuesta) * 2) * 0.08;
        const { error } = await supabase.from('registros_operativos').update({
            monto_apuesta: parseFloat(editingLog.monto_apuesta),
            fecha_operacion: editingLog.fecha_operacion,
            bando: editingLog.bando,
            ganancia_calculada: profit
        }).eq('id', editingLog.id);

        if (!error) {
            setEditingLog(null);
            loadMasterLogs();
        } else {
            alert(error.message);
        }
    };

    const handleUploadReceipt = async () => {
        if (!selectedUserForReceipt || !uploadUrl) return;
        const { error } = await supabase.from('perfiles_empleados').upsert({
            user_email: selectedUserForReceipt,
            comprobante_url: uploadUrl,
            ultimo_pago_update: new Date().toISOString()
        });

        if (!error) {
            alert('Comprobante asignado correctamente');
            setUploadUrl('');
            setSelectedUserForReceipt(null);
        } else {
            alert('Error: ' + error.message);
        }
    };

    const [forceSyncCount, setForceSyncCount] = useState(0);

    // --- SYNC & DATA GENERATION (DYNAMIC PERIOD) ---
    useEffect(() => {
        const syncData = async () => {
            // 1. Determine Date Range
            let startDate = new Date(selectedYear, selectedMonth, 1);
            let endDate = new Date(selectedYear, selectedMonth, 15);

            if (viewMode === 'Q1') {
                // REGLA ESPECIAL: La Q1 de Enero incluye desde el 29 de Diciembre anterior
                if (selectedMonth === 0) {
                    startDate = new Date(selectedYear - 1, 11, 29);
                } else {
                    startDate = new Date(selectedYear, selectedMonth, 1);
                }
                endDate = new Date(selectedYear, selectedMonth, 15);
            } else {
                startDate = new Date(selectedYear, selectedMonth, 16);
                endDate = new Date(selectedYear, selectedMonth + 1, 0); // End of month
            }

            // DATOS HISTORICOS DEMO (Hardcoded as requested)
            const prevYear = selectedYear - 1;
            const histData: any = {
                [`${prevYear}-12-29`]: { barco: 87800, cueva: 114450 },
                [`${prevYear}-12-30`]: { barco: 72300, cueva: 132496 },
                [`${prevYear}-12-31`]: { barco: 55400, cueva: 78940 },
                [`${selectedYear}-01-01`]: { barco: 0, cueva: 73649 },
                [`${selectedYear}-01-02`]: { barco: 11040, cueva: 53072 },
                [`${selectedYear}-01-03`]: { barco: 43712, cueva: 53152 },
                [`${selectedYear}-01-04`]: { barco: 27392, cueva: 39632 },
                [`${selectedYear}-01-05`]: { barco: 32624, cueva: 66048 },
                [`${selectedYear}-01-06`]: { barco: 45760, cueva: 64544 },
                [`${selectedYear}-01-07`]: { barco: 91536, cueva: 83712 },
                [`${selectedYear}-01-08`]: { barco: 63328, cueva: 60016 },
                [`${selectedYear}-01-09`]: { barco: 94832, cueva: 111920 }
            };

            let rows = [];
            // 2. Generate Grid (Iterate Dates)
            const current = new Date(startDate);
            while (current <= endDate) {
                const y = current.getFullYear();
                const m = (current.getMonth() + 1).toString().padStart(2, '0');
                const d = current.getDate().toString().padStart(2, '0');
                const fullDate = `${y}-${m}-${d}`; // Local YYYY-MM-DD

                // Label simple: "29", "30", "1" (User request)
                const label = parseInt(d).toString();

                const h = histData[fullDate] || { barco: 0, cueva: 0 };

                rows.push({
                    id: fullDate,
                    dia: label,
                    fullDate: fullDate,
                    barco: h.barco,
                    cueva: h.cueva,
                    mesasBarco: 0,
                    mesasCueva: 0,
                    gastos: 0, utilidad: 0, drop: 0
                });
                current.setDate(current.getDate() + 1);
            }

            // 3. Restore Manual Overrides (Expenses/Notes)
            const storageKey = `opData_${selectedYear}_${selectedMonth}_${viewMode}`;
            try {
                const saved = localStorage.getItem(storageKey);
                if (saved) {
                    const parsed = JSON.parse(saved);
                    rows = rows.map(r => {
                        // Match ONLY by fullDate to avoid cross-month data leakage
                        const s = parsed.find((p: any) => p.fullDate === r.fullDate);
                        return s ? { ...r, ...s, fullDate: r.fullDate } : r;
                    });
                }
            } catch (e) {
                console.error("Error loading overrides:", e);
                // Si falla, simplemente no cargamos los overrides, pero no crasheamos
            }

            // 4. Aggregate DB Data (Real Profit)
            const { data: dbRegs } = await supabase.from('registros_operativos').select('*');
            if (dbRegs) {
                const sums: any = {};
                dbRegs.forEach(reg => {
                    // reg.fecha_operacion is YYYY-MM-DD
                    if (!sums[reg.fecha_operacion]) sums[reg.fecha_operacion] = { barco: 0, cueva: 0, mesasBarco: 0, mesasCueva: 0 };

                    if (reg.bando === 'Barco') {
                        sums[reg.fecha_operacion].barco += reg.monto_apuesta;
                        sums[reg.fecha_operacion].mesasBarco += 1;
                    }
                    if (reg.bando === 'Cueva') {
                        sums[reg.fecha_operacion].cueva += reg.monto_apuesta;
                        sums[reg.fecha_operacion].mesasCueva += 1;
                    }
                });

                rows = rows.map(r => {
                    const dbSum = sums[r.fullDate];
                    if (dbSum) {
                        // Si la fila es MANUAL, NO la tocamos con datos de la DB
                        if (r.isManual) return r;

                        // Si no es manual, calculamos el profit real (8%)
                        const calculatedBarco = (dbSum.barco * 2) * 0.08;
                        const calculatedCueva = (dbSum.cueva * 2) * 0.08;

                        return {
                            ...r,
                            barco: calculatedBarco,
                            cueva: calculatedCueva,
                            mesasBarco: dbSum.mesasBarco,
                            mesasCueva: dbSum.mesasCueva
                        };
                    }
                    return r;
                });
            }
            setData(rows);
        };

        syncData();

        const subscription = supabase
            .channel('public:registros_operativos')
            .on('postgres_changes', { event: '*', schema: 'public', table: 'registros_operativos' }, () => {
                syncData();
            })
            .subscribe();

        return () => {
            subscription.unsubscribe();
        };
    }, [selectedMonth, selectedYear, viewMode, forceSyncCount]);

    useEffect(() => {
        if (showMasterModal) loadMasterLogs();
    }, [showMasterModal]);

    // Save Effects
    // Save Effects (Dynamic Key)
    useEffect(() => {
        if (data.length > 0) {
            localStorage.setItem(`opData_${selectedYear}_${selectedMonth}_${viewMode}`, JSON.stringify(data));
        }
    }, [data, selectedMonth, selectedYear, viewMode]);
    useEffect(() => { localStorage.setItem('shipmentsData', JSON.stringify(shipments)); }, [shipments]);
    useEffect(() => { localStorage.setItem('banksData', JSON.stringify(banks)); }, [banks]);
    useEffect(() => { localStorage.setItem('shiftsMatrixData', JSON.stringify(shiftsMatrix)); }, [shiftsMatrix]);
    useEffect(() => { localStorage.setItem('shiftsNotesData', JSON.stringify(shiftsNotes)); }, [shiftsNotes]);
    useEffect(() => { localStorage.setItem('employeesData', JSON.stringify(employees)); }, [employees]);
    useEffect(() => { localStorage.setItem('playersData', JSON.stringify(players)); }, [players]);

    const [felipeDays, setFelipeDays] = useState(() => loadState('felipeDays', 15));
    const [felipeExtraDays, setFelipeExtraDays] = useState(() => loadState('felipeExtraDays', 0));
    const [felipeAssignedFreeDays, setFelipeAssignedFreeDays] = useState(() => loadState('felipeAssignedFreeDays', 2)); // Default 2 días libres
    const [felipeAdvances, setFelipeAdvances] = useState(() => loadState('felipeAdvances', [])); // Nuevo Estado para Adelantos
    const [usdtRate, setUsdtRate] = useState(() => Number(loadState('usdtRate', 1100)));
    const [publicityActive, setPublicityActive] = useState(() => loadState('publicityActive', {}));
    const [pubARS, setPubARS] = useState(() => Number(loadState('pubARS', 0)));
    const [pubUSD, setPubUSD] = useState(() => Number(loadState('pubUSD', 0)));

    useEffect(() => { localStorage.setItem('felipeAssignedFreeDays', JSON.stringify(felipeAssignedFreeDays)); }, [felipeAssignedFreeDays]);

    useEffect(() => {
        localStorage.setItem('felipeDays', JSON.stringify(felipeDays));
        localStorage.setItem('felipeExtraDays', JSON.stringify(felipeExtraDays));
        localStorage.setItem('felipeAssignedFreeDays', JSON.stringify(felipeAssignedFreeDays));
        localStorage.setItem('felipeAdvances', JSON.stringify(felipeAdvances));
        localStorage.setItem('usdtRate', JSON.stringify(usdtRate));
        localStorage.setItem('publicityActive', JSON.stringify(publicityActive));
        localStorage.setItem('pubARS', JSON.stringify(pubARS));
        localStorage.setItem('pubUSD', JSON.stringify(pubUSD));
    }, [felipeDays, felipeExtraDays, felipeAssignedFreeDays, felipeAdvances, usdtRate, publicityActive, pubARS, pubUSD]);




    // Modals & Forms
    const [activeModal, setActiveModal] = useState<string | null>(null);
    const [editingItem, setEditingItem] = useState<any>(null);

    const [opForm, setOpForm] = useState({ dia: '', barco: '', cueva: '', mesasBarco: '', mesasCueva: '' });
    const [shipForm, setShipForm] = useState({ fecha: '', monto: '', nota: '', comprobante: '' });
    const [bankForm, setBankForm] = useState({ nombre: '', monto: '' });
    const [playerForm, setPlayerForm] = useState({ nombre: '', saldo: '' });
    const [employeeForm, setEmployeeForm] = useState({ name: '', status: 'Activo', group: 'Barco', shift: 'Mañana' });
    const [felipeAdvanceForm, setFelipeAdvanceForm] = useState({ motivo: '', monto: '' });

    const [binanceARS, setBinanceARS] = useState('');
    const [binanceUSDT, setBinanceUSDT] = useState('');
    const [isFetchingPrice, setIsFetchingPrice] = useState(false);
    const [showBinanceCalc, setShowBinanceCalc] = useState(false);

    // --- CALCULADORA STATE ---
    const [showCalc, setShowCalc] = useState(false);
    const [calcValue, setCalcValue] = useState('0');
    const [pendingOp, setPendingOp] = useState<string | null>(null);
    const [prevValue, setPrevValue] = useState<string | null>(null);

    const handleCalcAction = (action: string) => {
        if (/[0-9]/.test(action)) {
            setCalcValue(prev => (prev === '0' ? action : prev + action));
        } else if (action === '.') {
            if (!calcValue.includes('.')) setCalcValue(prev => prev + '.');
        } else if (action === 'C') {
            setCalcValue('0');
            setPendingOp(null);
            setPrevValue(null);
        } else if (action === '=') {
            if (pendingOp && prevValue !== null) {
                const current = parseFloat(calcValue);
                const previous = parseFloat(prevValue);
                let result = 0;
                if (pendingOp === '+') result = previous + current;
                if (pendingOp === '-') result = previous - current;
                if (pendingOp === '*') result = previous * current;
                if (pendingOp === '/') result = current !== 0 ? previous / current : 0;

                const finalResult = Math.round(result * 100) / 100;
                setCalcValue(finalResult.toString());
                setPendingOp(null);
                setPrevValue(null);
            }
        } else {
            if (pendingOp && prevValue !== null && calcValue !== '0') {
                const current = parseFloat(calcValue);
                const previous = parseFloat(prevValue);
                let partial = 0;
                if (pendingOp === '+') partial = previous + current;
                if (pendingOp === '-') partial = previous - current;
                if (pendingOp === '*') partial = previous * current;
                if (pendingOp === '/') partial = current !== 0 ? previous / current : 0;

                setPrevValue(partial.toString());
                setPendingOp(action);
                setCalcValue('0');
            } else {
                setPendingOp(action);
                setPrevValue(calcValue);
                setCalcValue('0');
            }
        }
    };

    // --- AUTO-SAVE STATES ---
    const [isLoaded, setIsLoaded] = useState(false);
    const [isOnline, setIsOnline] = useState(navigator.onLine);
    const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');

    // Identificador único de sesión para evitar bucles infinitos en Realtime
    const [sessionId] = useState(() => Math.random().toString(36).substring(7));
    const isRemoteUpdate = useState({ current: false })[0]; // Usamos objeto mutable para persistencia entre renders

    // Formatters
    const formatCurrency = (value: number) => {
        return new Intl.NumberFormat('es-AR', {
            style: 'currency',
            currency: 'ARS',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(value);
    };

    const formatUSD = (value: number) => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(value);
    }

    const formatNumber = (value: number) => {
        return new Intl.NumberFormat('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
    }

    // Logic
    const daysInFortnight = currentFortnight === 1
        ? Array.from({ length: 15 }, (_, i) => i + 1)
        : Array.from({ length: 16 }, (_, i) => i + 16);

    // Helpper to parse "8:30" => 8.5
    const parseHours = (val: string | number): number => {
        if (typeof val === 'number') return val;
        if (!val) return 0;

        // Handle "HH:MM"
        if (val.includes(':')) {
            const [h, m] = val.split(':').map(Number);
            return (h || 0) + ((m || 0) / 60);
        }

        // Handle normal numbers (replace comma with dot just in case)
        return parseFloat(val.replace(',', '.')) || 0;
    };

    const handleShiftChange = (empId: any, day: number, value: any) => {
        setShiftsMatrix((prev: any) => ({
            ...prev,
            [empId]: { ...prev[empId], [day]: value }
        }));
    };

    const getShiftValue = (empId: any, day: number) => {
        const val = shiftsMatrix[empId]?.[day] || '';
        if (typeof val === 'object' && val !== null) return val.horas || '';
        return val;
    };

    const calculateEmployeeStats = (empId: any) => {
        const empShifts = shiftsMatrix[empId] || {};
        let totalHours = 0;
        daysInFortnight.forEach(day => {
            const val = empShifts[day];
            if (typeof val === 'object' && val !== null) {
                totalHours += parseHours(val.horas);
            } else {
                totalHours += parseHours(val);
            }
        });

        const shiftsCount = totalHours / HOURS_PER_SHIFT;
        const totalPayUSD = shiftsCount * SHIFT_VALUE_USD;

        return { totalHours, totalPayUSD };
    };

    const handleSaveOp = (e: any) => {
        e.preventDefault();
        const newItem = {
            id: editingItem?.id || Date.now(),
            dia: opForm.dia,
            fullDate: editingItem?.fullDate || `${selectedYear}-${(selectedMonth + 1).toString().padStart(2, '0')}-${opForm.dia.padStart(2, '0')}`,
            barco: Math.max(0, parseFloat(opForm.barco) || 0),
            cueva: Math.max(0, parseFloat(opForm.cueva) || 0),
            mesasBarco: Math.max(0, parseInt(opForm.mesasBarco) || 0),
            mesasCueva: Math.max(0, parseInt(opForm.mesasCueva) || 0),
            isManual: true // Marca como edición manual
        };
        if (editingItem) setData(data.map((d: any) => d.id === newItem.id ? newItem : d));
        else setData([...data, newItem]);
        setActiveModal(null);
    };
    const handleDeleteOp = (id: number) => { if (confirm('Borrar?')) setData(data.filter((d: any) => d.id !== id)); };

    const handleSaveShip = (e: any) => { e.preventDefault(); const newItem = { id: editingItem?.id || Date.now(), fecha: shipForm.fecha, monto: parseFloat(shipForm.monto), nota: shipForm.nota, comprobante: shipForm.comprobante }; if (editingItem) setShipments(shipments.map((s: any) => s.id === newItem.id ? newItem : s)); else setShipments([...shipments, newItem]); setActiveModal(null); };
    const handleDeleteShip = (id: number) => { if (confirm('Borrar?')) setShipments(shipments.filter((s: any) => s.id !== id)); };

    const handleSaveBank = (e: any) => { e.preventDefault(); const newItem = { id: editingItem?.id || Date.now(), nombre: bankForm.nombre, monto: parseFloat(bankForm.monto) }; if (editingItem) setBanks(banks.map((b: any) => b.id === newItem.id ? newItem : b)); else setBanks([...banks, newItem]); setActiveModal(null); };
    const handleDeleteBank = (id: number) => { if (confirm('Borrar?')) setBanks(banks.filter((b: any) => b.id !== id)); };

    const handleSaveEmployee = async (e: any) => {
        e.preventDefault();
        const newItem = {
            id: editingItem?.id || Date.now(),
            name: employeeForm.name,
            status: employeeForm.status,
            group: employeeForm.group,
            shift: employeeForm.shift
        };

        // 1. Update Local State immediately
        if (editingItem) setEmployees(employees.map((em: any) => em.id === newItem.id ? newItem : em));
        else setEmployees([...employees, newItem]);
        setActiveModal(null);

        // 2. Persist to 'usuarios_sistema' (The "Principal" DB)
        // Map Group to Role
        let dbRole = 'fijo_barco';
        if (newItem.group === 'Cueva') dbRole = 'fijo_cueva';
        if (newItem.shift === 'Franquero') dbRole = 'franquero'; // Optional override

        // Use name as username ID if random ID
        const dbId = typeof newItem.id === 'string' ? newItem.id : `${newItem.name.toLowerCase().replace(/\s+/g, '.')}.${Math.floor(Math.random() * 1000)}`;

        const { error } = await supabase.from('usuarios_sistema').upsert({
            id: editingItem?.id && typeof editingItem.id === 'string' ? editingItem.id : undefined, // Let DB handle ID if not string, or use generate
            username: dbId,
            nombre: newItem.name,
            role: dbRole,
            estado: newItem.status === 'Activo' ? 'aprobado' : 'pendiente' // Default to aprobado/pendiente
        }, { onConflict: 'username' });

        if (error) {
            console.error("Error syncing to usuarios_sistema:", error);
            alert("Guardado localmente, pero error conectando con DB Principal: " + error.message);
        } else {
            // Re-sync to ensure everything matches
            // setTimeout(syncEmployeesWithDB, 1000); 
        }
    };
    const handleDeleteEmployee = (id: number) => { if (confirm('Borrar?')) setEmployees(employees.filter((em: any) => em.id !== id)); };

    const handleSaveFelipeAdvance = (e: any) => {
        e.preventDefault();
        const newItem = { id: editingItem?.id || Date.now(), motivo: felipeAdvanceForm.motivo, monto: parseFloat(felipeAdvanceForm.monto) };
        if (editingItem) setFelipeAdvances(felipeAdvances.map((a: any) => a.id === newItem.id ? newItem : a));
        else setFelipeAdvances([...(felipeAdvances || []), newItem]);
        setActiveModal(null);
    };
    const handleDeleteFelipeAdvance = (id: number) => { if (confirm('Borrar adelanto?')) setFelipeAdvances(felipeAdvances.filter((a: any) => a.id !== id)); };


    const syncEmployeesWithDB = async () => {
        const { data: dbUsers } = await supabase
            .from('usuarios_sistema')
            .select('*')
            .in('role', ['fijo_barco', 'fijo_cueva', 'franquero'])
            .eq('estado', 'aprobado');

        if (dbUsers) {
            setEmployees((prev: any[]) => {
                const currentMap = new Map(prev.map((e: any) => [e.email || e.id, e]));
                const updated = dbUsers.map(u => {
                    const existing = currentMap.get(u.username) as any;
                    return {
                        id: u.username, // Usar username como ID estable
                        name: u.nombre,
                        email: u.username,
                        status: existing?.status || 'Activo',
                        group: u.role === 'fijo_barco' ? 'Barco' : u.role === 'fijo_cueva' ? 'Cueva' : (existing?.group || 'Barco'),
                        shift: existing?.shift || 'Mañana'
                    };
                });
                return updated;
            });
        }
    };




    // --- SUPABASE INTEGRATION: FULL SYNC ---

    // 1. Cargar Estado Completo al Inicio
    // --- SUPABASE INTEGRATION: FULL SYNC & REALTIME ---

    useEffect(() => {
        const handleOnlineStatus = () => setIsOnline(navigator.onLine);
        window.addEventListener('online', handleOnlineStatus);
        window.addEventListener('offline', handleOnlineStatus);
        return () => {
            window.removeEventListener('online', handleOnlineStatus);
            window.removeEventListener('offline', handleOnlineStatus);
        };
    }, []);

    // 1. Cargar Estado Completo al Inicio y Suscribirse a Cambios
    useEffect(() => {
        const fetchFullState = async () => {
            console.log('🔄 Sincronizando: Buscando respaldo en nube...');
            try {
                const { data: backupData } = await supabase
                    .from('app_backups')
                    .select('content')
                    .eq('id', 1)
                    .single();

                if (backupData?.content) {
                    hydrateState(backupData.content);
                }
            } catch (err) {
                console.error('Excepción al cargar:', err);
            } finally {
                setIsLoaded(true);
                // SINCRONIZACION DINAMICA DE EMPLEADOS DESDE LA DB PRINCIPAL
                syncEmployeesWithDB();
            }
        };

        const hydrateState = (c: any) => {
            console.log('💧 Hidratando estado desde la nube...');
            isRemoteUpdate.current = true; // Marcar como actualización remota para evitar re-guardado

            // IMPORTANTE: NO SOBRESCRIBIMOS "data" (Operative) DIRECTAMENTE desde el backup
            // Porque el backup puede ser viejo y sobrescribir el cálculo de "Ganancia Real"
            // En su lugar, si hay overrides manuales en el backup, podríamos guardarlos (opcional)
            // Pero para arreglar el bug de $0, lo mejor es dejar que syncData() haga su trabajo.
            if (c.operative && c.operative.length > 0) {
                // Opción: Guardar esto en localStorage para que syncData lo use como override si hace falta
                // Pero NO llamar setData(c.operative)
                localStorage.setItem(`opData_${selectedYear}_${selectedMonth}_${viewMode}`, JSON.stringify(c.operative));
                // FORZAR RE-SYNC para que lea el localStorage nuevo + la DB real
                setForceSyncCount(prev => prev + 1);
            }

            if (c.shipments && c.shipments.length > 0) setShipments(c.shipments);
            if (c.banks && c.banks.length > 0) setBanks(c.banks);
            if (c.players && c.players.length > 0) setPlayers(c.players);
            if (c.employees && c.employees.length > 0) setEmployees(c.employees);

            // SEGURIDAD: Solo hidratar turnos si el backup contiene datos reales
            if (c.shifts && Object.keys(c.shifts).length > 0) {
                setShiftsMatrix(c.shifts);
            }
            if (c.shiftsNotes && Object.keys(c.shiftsNotes).length > 0) {
                setShiftsNotes(c.shiftsNotes);
            }

            if (c.felipe) {
                if (c.felipe.days !== undefined) setFelipeDays(c.felipe.days);
                if (c.felipe.extra !== undefined) setFelipeExtraDays(c.felipe.extra);
                if (c.felipe.free !== undefined) setFelipeAssignedFreeDays(c.felipe.free);
                if (c.felipe.advances !== undefined) setFelipeAdvances(c.felipe.advances);
            }
            if (c.usdtRate !== undefined) setUsdtRate(c.usdtRate);
            if (c.publicityActive !== undefined) setPublicityActive(c.publicityActive);
            if (c.pubARS !== undefined) setPubARS(c.pubARS);
            if (c.pubUSD !== undefined) setPubUSD(c.pubUSD);
            if (c.includePublicityInTotal !== undefined) setIncludePublicityInTotal(c.includePublicityInTotal);

            // Hack para resetear la bandera después de que se procesen los efectos
            setTimeout(() => { isRemoteUpdate.current = false; }, 500);
        };

        fetchFullState();

        // --- REALTIME SUBSCRIPTION ---
        const channel = supabase
            .channel('dashboard-changes')
            .on(
                'postgres_changes',
                { event: 'UPDATE', schema: 'public', table: 'app_backups', filter: 'id=eq.1' },
                (payload) => {
                    const newContent = payload.new.content;
                    // Evitar "Echo": Si el cambio lo hice yo (mi sessionId), lo ignoro.
                    if (newContent?.meta?.sessionId === sessionId) {
                        return;
                    }
                    console.log('📡 Cambio recibido en tiempo real de otro usuario!');
                    hydrateState(newContent);
                    setSaveStatus('saved'); // Mostrar check verde para indicar que estamos sync
                    setTimeout(() => setSaveStatus('idle'), 2000);
                }
            )
            .subscribe();

        return () => {
            supabase.removeChannel(channel);
        };
    }, []);

    // 2. Función de Guardado (Reutilizable)
    const saveToCloud = async (silent = false) => {
        if (!silent) setSaveStatus('saving');

        const fullBackup = {
            operative: data,
            shipments: shipments,
            banks: banks,
            players: players,
            employees: employees,
            shifts: shiftsMatrix,
            shiftsNotes: shiftsNotes,
            felipe: { days: felipeDays, extra: felipeExtraDays, free: felipeAssignedFreeDays, advances: felipeAdvances },
            usdtRate: usdtRate,
            publicityActive: publicityActive,
            pubARS: pubARS,
            pubUSD: pubUSD,
            includePublicityInTotal: includePublicityInTotal,
            meta: {
                timestamp: new Date().toISOString(),
                user: role,
                sessionId: sessionId // Firmamos el cambio con nuestra ID
            }
        };

        // SEGURIDAD: Antes de guardar, verificamos que no estemos guardando algo vacío si ya hay datos
        if (data.length === 0 && employees.length === 0 && shipments.length === 0) {
            // Si todo está vacío, podría ser un error de carga. No sobrescribimos el backup principal.
            console.warn("⚠️ Intento de guardar estado vacío. Abortando para proteger la DB.");
            return;
        }

        // 1. Guardar como principal (ID 1)
        const { error } = await supabase.from('app_backups').upsert({
            id: 1,
            updated_at: new Date().toISOString(),
            content: fullBackup
        }, { onConflict: 'id' });

        // 2. Guardar HISTORIAL (ID basado en timestamp) - Esto asegura que NADA se borre para siempre
        // Guardamos una versión cada hora como máximo para no saturar
        const hourlyId = Math.floor(Date.now() / (1000 * 60 * 60));
        await supabase.from('app_backups').upsert({
            id: hourlyId,
            updated_at: new Date().toISOString(),
            content: fullBackup
        }, { onConflict: 'id' });

        if (error) {
            console.error('Error guardando:', error);
            if (!silent) {
                setSaveStatus('error');
                alert(`⚠️ ERROR DE GUARDADO: ${error.message || 'Error desconocido'}`);
            }
        } else {
            console.log('☁️ Estado guardado en Supabase (con respaldo histórico)');
            if (!silent) setSaveStatus('saved');
            if (!silent) setTimeout(() => setSaveStatus('idle'), 2000);
        }
    };

    // 3. Auto-Save Effect (Debounced)
    useEffect(() => {
        if (!isLoaded) return;

        // CRÍTICO: Si el cambio vino de fuera (Realtime), NO lo guardamos de vuelta.
        if (isRemoteUpdate.current) {
            return;
        }

        setSaveStatus('saving');

        const timer = setTimeout(() => {
            saveToCloud();
        }, 1500); // Acortamos a 1.5s para mayor "instaneidad"

        return () => clearTimeout(timer);
    }, [data, shipments, banks, players, employees, shiftsMatrix, shiftsNotes, felipeDays, felipeExtraDays, felipeAssignedFreeDays, felipeAdvances, usdtRate, publicityActive, pubARS, pubUSD, isLoaded]);

    // 4. Bloqueo de salida si está guardando
    useEffect(() => {
        const handleBeforeUnload = (e: BeforeUnloadEvent) => {
            if (saveStatus === 'saving') {
                e.preventDefault();
                e.returnValue = 'Guardado en progreso. ¿Seguro que quieres salir?';
            }
        };
        window.addEventListener('beforeunload', handleBeforeUnload);
        return () => window.removeEventListener('beforeunload', handleBeforeUnload);
    }, [saveStatus]);

    // --- ACTIONS HANDLERS ---

    // Manual Trigger (ahora usa la misma logica)




    const handleSavePlayer = (e: any) => { e.preventDefault(); if (editingItem) setPlayers(players.map((p: any) => p.id === editingItem.id ? { ...p, saldo: parseFloat(playerForm.saldo) } : p)); setActiveModal(null); };

    const totalBarco = data.reduce((sum: any, item: any) => sum + item.barco, 0);
    const totalCueva = data.reduce((sum: any, item: any) => sum + item.cueva, 0);
    const totalEnviado = shipments.reduce((sum: any, item: any) => sum + item.monto, 0);

    // --- TOP PERFORMANCE LOGIC (QUINCENA) ---
    const topEmployees = employees
        .map((emp: any) => ({
            name: emp.name,
            group: emp.group,
            stats: calculateEmployeeStats(emp.id)
        }))
        .filter((emp: any) => emp.stats.totalHours > 0)
        .sort((a: any, b: any) => b.stats.totalHours - a.stats.totalHours)
        .slice(0, 3);

    const maxHours = topEmployees.length > 0 ? Math.max(...topEmployees.map((e: any) => e.stats.totalHours)) : 100;

    // --- CALCULOS PUBLICIDAD SINCRONIZADA ---
    const fortnightActivePublicity = Object.keys(publicityActive).filter(k => {
        const [y, m, _d] = k.split('-').map(Number);
        return y === selectedYear && m === (selectedMonth + 1) && daysInFortnight.includes(_d);
    });

    const totalFortnightPubARS_Barco = fortnightActivePublicity.reduce((acc, k) => acc + (publicityActive[k]?.Barco || 0), 0);
    const totalFortnightPubARS_Cueva = fortnightActivePublicity.reduce((acc, k) => acc + (publicityActive[k]?.Cueva || 0), 0);
    const totalFortnightPubARS_Total = totalFortnightPubARS_Barco + totalFortnightPubARS_Cueva;

    const totalFortnightPubUSD_Barco = usdtRate > 0 ? totalFortnightPubARS_Barco / usdtRate : 0;
    const totalFortnightPubUSD_Cueva = usdtRate > 0 ? totalFortnightPubARS_Cueva / usdtRate : 0;
    const totalFortnightPubUSD_Total = usdtRate > 0 ? totalFortnightPubARS_Total / usdtRate : 0;

    const monthlyActivePublicity = Object.keys(publicityActive).filter(k => {
        const [y, m, _d] = k.split('-').map(Number);
        return y === selectedYear && m === (selectedMonth + 1);
    });

    const totalMonthPubARS_Barco = monthlyActivePublicity.reduce((acc, k) => acc + (publicityActive[k]?.Barco || 0), 0);
    const totalMonthPubARS_Cueva = monthlyActivePublicity.reduce((acc, k) => acc + (publicityActive[k]?.Cueva || 0), 0);
    const totalMonthPubARS_Total = totalMonthPubARS_Barco + totalMonthPubARS_Cueva;

    const totalMonthPubUSD_Total = usdtRate > 0 ? totalMonthPubARS_Total / usdtRate : 0;

    // --- CALCULOS NOMINA FINAL ---
    const staffTotalUSD = employees.reduce((acc: number, emp: any) => acc + calculateEmployeeStats(emp.id).totalPayUSD, 0);
    const felipeTotalUSD = ((felipeDays + felipeExtraDays) * 28.84) - ((felipeAdvances || []).reduce((acc: number, cur: any) => acc + (cur.monto || 0), 0));
    const subTotalPayrollUSD = staffTotalUSD + felipeTotalUSD;
    const grandTotalUSD = subTotalPayrollUSD + (includePublicityInTotal ? totalFortnightPubUSD_Total : 0);

    const fetchLivePrice = async () => {
        setIsFetchingPrice(true);
        try {
            const res = await fetch('https://criptoya.com/api/binance/usdt/ars/1');
            const data = await res.json();
            if (data.ask) {
                setUsdtRate(Math.ceil(data.ask));
            }
        } catch (e) {
            console.error("Error fetching price", e);
        } finally {
            setIsFetchingPrice(false);
        }
    };

    // Auto-fetch price on mount
    useEffect(() => {
        fetchLivePrice();
    }, []);

    // Reactive calculation when rate changes
    useEffect(() => {
        if (binanceARS && usdtRate > 0) {
            setBinanceUSDT((parseFloat(binanceARS) / usdtRate).toFixed(2));
        }
    }, [usdtRate]);


    if (showPublicityAnalytics) {
        return <PublicityDashboard user={{ email: userEmail, role, name: role === 'admin' ? 'Master Admin' : 'Admin User' }} onLogout={onLogout} onBack={() => setShowPublicityAnalytics(false)} readOnly={role === 'admin'} usdtRate={usdtRate} initialGroup={dashboardGroup === 'Todos' ? 'Barco' : dashboardGroup} />;
    }

    return (
        <div className="min-h-screen bg-slate-950 text-slate-100 font-sans relative pb-20 selection:bg-purple-500/50">
            {/* STATUS INDICATOR BOTTOM RIGHT */}
            <div className={`fixed bottom-4 right-4 z-[100] px-4 py-2 rounded-full border backdrop-blur-md shadow-lg flex items-center gap-3 transition-all duration-300 font-bold text-xs uppercase tracking-widest ${!isOnline ? 'bg-red-500/20 border-red-500/50 text-red-500 translate-y-0 opacity-100' : saveStatus === 'saving' ? 'bg-yellow-500/10 border-yellow-500/30 text-yellow-400 translate-y-0 opacity-100' : saveStatus === 'saved' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 translate-y-0 opacity-100' : saveStatus === 'error' ? 'bg-red-500/10 border-red-500/30 text-red-500 translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
                {!isOnline && (
                    <>
                        <RefreshCw size={14} className="animate-spin" />
                        <span>MODO OFFLINE (RECONECTANDO...)</span>
                    </>
                )}
                {isOnline && saveStatus === 'saving' && (
                    <>
                        <RefreshCw size={14} className="animate-spin" />
                        <span>Sincronizando...</span>
                    </>
                )}
                {isOnline && saveStatus === 'saved' && (
                    <>
                        <span className="relative flex h-2 w-2">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                        </span>
                        <span>Guardado</span>
                        <span className="text-[9px] opacity-70 normal-case border-l border-emerald-500/30 pl-2 ml-1">
                            {role === 'admin' ? `Admin: ${role}` : `User: ${role}`}
                        </span>
                    </>
                )}
                {isOnline && saveStatus === 'error' && <span>Error al guardar</span>}
            </div>

            {/* FUTURISTIC BACKGROUND */}
            {/* MODERN DEEP BACKGROUND - NO NOISE */}
            <div className="fixed inset-0 overflow-hidden pointer-events-none z-0 bg-slate-950">
                <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-[#0f0c29] to-[#0b0f19] opacity-100"></div>
                <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-[#4f46e5]/10 rounded-full blur-[120px] animate-pulse-slow"></div>
                <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-[#3b82f6]/10 rounded-full blur-[120px] animate-pulse-slow delay-1000"></div>
                <div className="absolute top-[40%] left-[20%] w-[30%] h-[30%] bg-[#a855f7]/5 rounded-full blur-[100px]"></div>
            </div>

            <div className="relative z-10 p-4 max-w-[1800px] mx-auto space-y-6">

                {/* HEADER */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 py-4 border-b border-indigo-500/20 bg-slate-900/40 backdrop-blur-xl rounded-2xl px-6 shadow-2xl shadow-indigo-500/10">
                    <div className="flex flex-col items-center md:items-start gap-3">
                        <div className="p-3 bg-white/5 rounded-xl border border-white/10 shadow-lg shadow-black/20">
                            <img src="/logo.png" alt="FMX Logo" className="w-48 md:w-64 h-auto drop-shadow-lg" />
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-indigo-300/80 font-mono tracking-[0.2em] uppercase bg-black/20 px-3 py-1.5 rounded-full border border-white/5">
                            <div className="flex items-center gap-1.5">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399] animate-pulse"></span>
                                <span className="text-emerald-400">ONLINE</span>
                            </div>
                            <span className="text-slate-600 mx-1">|</span>
                            <span>SISTEMA OPERATIVO V3.1</span>
                        </div>

                        {/* SELECTOR DE GRUPO GLOBAL */}
                        <div className="flex bg-slate-950/60 p-1 rounded-xl border border-white/5 shadow-inner">
                            {['Todos', 'Barco', 'Cueva'].map((g) => (
                                <button
                                    key={g}
                                    onClick={() => setDashboardGroup(g as any)}
                                    className={`px-4 py-2 rounded-lg text-[9px] font-black uppercase transition-all flex items-center gap-2 ${dashboardGroup === g ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
                                >
                                    {g === 'Todos' ? <Users size={12} /> : g === 'Barco' ? <Ship size={12} /> : <Mountain size={12} />}
                                    {g === 'Todos' ? 'General' : g}
                                </button>
                            ))}
                        </div>
                    </div>
                    <div className="flex gap-3 items-center">
                        {/* TOOLS (ADMIN ONLY) */}
                        {role === 'admin' && (
                            <button onClick={() => setShowMasterModal(true)} className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 hover:bg-indigo-500/20 transition-all no-print" title="Vista Maestra Operativa">
                                <FileText size={20} />
                            </button>
                        )}



                        {/* LOGOUT (ALL USERS) */}
                        <button onClick={onLogout} className="p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-400 hover:text-white hover:bg-red-900/50 hover:border-red-500/30 transition-all no-print" title="Cerrar Sesión">
                            <Lock size={20} />
                        </button>

                        {/* MANUAL SAVE (ADMIN) */}
                        {role === 'admin' && (
                            <button onClick={() => saveToCloud()} className="p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 hover:bg-blue-500/20 transition-all no-print active:scale-95" title="Guardar Manualmente">
                                <Send size={20} />
                            </button>
                        )}

                        {/* CALCULADORA (NUEVA POSICIÓN) */}
                        <button onClick={() => setShowCalc(!showCalc)} className={`p-2.5 rounded-xl border transition-all no-print ${showCalc ? 'bg-amber-500/40 border-amber-500/60 text-white shadow-[0_0_15px_rgba(245,158,11,0.3)]' : 'bg-amber-500/10 border-amber-500/20 text-amber-500 hover:bg-amber-500/20'}`} title="Calculadora Normal">
                            <CalcIcon size={20} />
                        </button>

                        {/* BINANCE CONVERTER (NUEVA POSICIÓN) */}
                        <button onClick={() => setShowBinanceCalc(!showBinanceCalc)} className={`p-2.5 rounded-xl border transition-all no-print ${showBinanceCalc ? 'bg-yellow-500/40 border-yellow-500/60 text-white shadow-[0_0_15px_rgba(234,179,8,0.3)]' : 'bg-yellow-500/10 border-yellow-500/20 text-yellow-500 hover:bg-yellow-500/20'}`} title="Binance Live Converter">
                            <CircleDollarSign size={20} />
                        </button>

                        {/* NÓMINA PRINCIPAL NAVIGATION (WIDE VIEW) */}
                        {role === 'admin' && (
                            <button onClick={() => setShowNominaPage(true)} className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 hover:bg-indigo-500/20 transition-all no-print flex items-center gap-2 font-bold text-[10px] uppercase tracking-widest" title="Abrir Nómina Principal">
                                <Users size={18} /> NÓMINA
                            </button>
                        )}

                        {/* ADD DAY (ADMIN) */}
                        {role === 'admin' && (
                            <button onClick={() => { setActiveModal('operative'); setEditingItem(null); setOpForm({ dia: '', barco: '', cueva: '', mesasBarco: '', mesasCueva: '' }) }} className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white px-3 py-2 md:px-5 md:py-2.5 rounded-xl flex items-center gap-1.5 md:gap-2 text-[10px] md:text-sm font-bold shadow-lg shadow-emerald-500/20 transition-all border border-emerald-400/20 hover:scale-105 active:scale-95 no-print uppercase">
                                <PlusCircle size={14} className="md:w-[18px] md:h-[18px]" /> AGREGAR DÍA
                            </button>
                        )}
                    </div>
                </div>

                {/* --- KPI SUMMARY PREMIUM (3 CARDS) --- */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {[
                        {
                            title: 'TOTAL GANANCIA',
                            icon: Activity,
                            color: 'indigo',
                            value: totalBarco + totalCueva,
                            details: [
                                { label: 'Barco', val: totalBarco, color: 'text-yellow-400' },
                                { label: 'Cueva', val: totalCueva, color: 'text-pink-400' }
                            ]
                        },
                        {
                            title: 'T. ENVIADO',
                            icon: Send,
                            color: 'purple',
                            value: shipments.filter((s: any) => dashboardGroup === 'Todos' || s.grupo === dashboardGroup).reduce((acc: any, s: any) => acc + s.monto, 0)
                        },
                        {
                            title: 'LIQUIDEZ',
                            icon: Landmark,
                            color: 'emerald',
                            value: banks.reduce((acc: any, b: any) => acc + (parseFloat(b.monto) || 0), 0)
                        },
                    ].map((kpi, idx) => (
                        <div key={idx} className={`bg-slate-900/60 backdrop-blur-2xl border border-${kpi.color}-500/20 p-6 rounded-[2rem] relative overflow-hidden group hover:border-${kpi.color}-500/40 transition-all duration-500 hover:shadow-2xl hover:shadow-${kpi.color}-500/10`}>
                            <div className={`absolute -right-4 -top-4 text-${kpi.color}-500 opacity-5 group-hover:opacity-10 group-hover:scale-125 transition-all duration-700`}><kpi.icon size={120} /></div>

                            <div className="flex flex-col relative z-10 h-full justify-between">
                                <div>
                                    <span className={`text-${kpi.color}-400 text-[10px] font-black tracking-[0.2em] uppercase mb-4 block`}>{kpi.title}</span>
                                    <div className="flex items-baseline gap-2">
                                        <span className="text-3xl md:text-4xl font-black text-white font-mono tracking-tighter transition-all group-hover:drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]">
                                            {formatCurrency(kpi.value)}
                                        </span>
                                    </div>
                                </div>

                                {kpi.details && (
                                    <div className="mt-6 pt-4 border-t border-white/5 grid grid-cols-2 gap-4">
                                        {kpi.details.map((det, i) => (
                                            <div key={i} className="flex flex-col">
                                                <span className="text-[8px] text-slate-500 font-bold uppercase tracking-widest">{det.label}</span>
                                                <span className={`text-sm font-mono font-bold ${det.color}`}>{formatCurrency(det.val)}</span>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>
                    ))}
                </div>

                {/* --- MAIN CONTENT --- */}
                <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">

                    {/* LEFT COLUMN */}
                    <div className="xl:col-span-2 space-y-6">

                        {/* HISTORICO OPERATIVO TABLE */}
                        <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-700/50 rounded-2xl overflow-hidden shadow-2xl relative group">
                            <div className="absolute inset-0 bg-gradient-to-b from-blue-500/5 to-transparent pointer-events-none"></div>
                            <div className="px-5 py-4 border-b border-slate-700/50 flex flex-wrap gap-4 justify-between items-center bg-slate-900/80">
                                <h2 className="font-bold text-white flex items-center gap-2 text-sm uppercase tracking-widest">
                                    <div className="p-1.5 bg-yellow-400/20 rounded text-yellow-400"><Activity size={16} /></div>
                                    Registro Diario
                                </h2>

                                {/* CONTROLS */}
                                <div className="flex items-center gap-2">
                                    <select
                                        value={selectedMonth}
                                        onChange={e => setSelectedMonth(Number(e.target.value))}
                                        className="bg-slate-950 text-white text-xs py-1.5 px-3 rounded-lg border border-slate-700 outline-none focus:border-yellow-500 transition-colors"
                                    >
                                        {['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'].map((m, i) => (
                                            <option key={i} value={i}>{m}</option>
                                        ))}
                                    </select>

                                    <select
                                        value={selectedYear}
                                        onChange={e => setSelectedYear(Number(e.target.value))}
                                        className="bg-slate-950 text-white text-xs py-1.5 px-3 rounded-lg border border-slate-700 outline-none focus:border-yellow-500 transition-colors"
                                    >
                                        <option value={2025}>2025</option>
                                        <option value={2026}>2026</option>
                                    </select>

                                    <div className="flex bg-slate-950 rounded-lg border border-slate-700 p-1">
                                        <button
                                            onClick={() => setViewMode('Q1')}
                                            className={`px-3 py-1 text-[10px] font-bold rounded-md transition-all ${viewMode === 'Q1' ? 'bg-yellow-500 text-slate-950 shadow-lg shadow-yellow-500/20' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
                                        >
                                            Q1 (1-15)
                                        </button>
                                        <button
                                            onClick={() => setViewMode('Q2')}
                                            className={`px-3 py-1 text-[10px] font-bold rounded-md transition-all ${viewMode === 'Q2' ? 'bg-yellow-500 text-slate-950 shadow-lg shadow-yellow-500/20' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
                                        >
                                            Q2 (16-End)
                                        </button>
                                    </div>
                                </div>
                            </div>


                            {/* --- CHART SECTION --- */}
                            <div className="h-64 w-full bg-slate-900/40 border-b border-slate-800/50 relative">
                                <div className="absolute top-4 right-4 flex gap-4 text-[10px] font-bold uppercase tracking-widest z-10">
                                    {(dashboardGroup === 'Todos' || dashboardGroup === 'Barco') && <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-yellow-400 shadow-[0_0_8px_#facc15]"></span> Barco</div>}
                                    {(dashboardGroup === 'Todos' || dashboardGroup === 'Cueva') && <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-[#ff0099] shadow-[0_0_10px_#ff0099]"></span> Cueva</div>}
                                </div>
                                <ResponsiveContainer width="100%" height="100%">
                                    <AreaChart data={data} margin={{ top: 20, right: 10, left: 0, bottom: 0 }}>
                                        <defs>
                                            <linearGradient id="colorBarco" x1="0" y1="0" x2="0" y2="1">
                                                <stop offset="5%" stopColor="#facc15" stopOpacity={0.6} />
                                                <stop offset="95%" stopColor="#facc15" stopOpacity={0} />
                                            </linearGradient>
                                            <linearGradient id="colorCueva" x1="0" y1="0" x2="0" y2="1">
                                                <stop offset="5%" stopColor="#ff0099" stopOpacity={0.6} />
                                                <stop offset="95%" stopColor="#ff0099" stopOpacity={0} />
                                            </linearGradient>
                                        </defs>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} vertical={false} />
                                        <XAxis dataKey="dia" stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} />
                                        <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value / 1000}k`} />
                                        <Tooltip
                                            contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', borderColor: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(10px)', color: '#f1f5f9', borderRadius: '12px', boxShadow: '0 0 20px rgba(0,0,0,0.5)' }}
                                            itemStyle={{ fontSize: '12px', fontWeight: 'bold' }}
                                            formatter={(value: number | undefined) => formatCurrency(value || 0)}
                                            labelStyle={{ color: '#94a3b8', marginBottom: '5px' }}
                                        />
                                        {(dashboardGroup === 'Todos' || dashboardGroup === 'Barco') && (
                                            <Area type="monotone" dataKey="barco" stroke="#facc15" strokeWidth={3} fillOpacity={1} fill="url(#colorBarco)" animationDuration={2000} animationEasing="ease-in-out" style={{ filter: 'drop-shadow(0 0 8px rgba(250, 204, 21, 0.5))' }} />
                                        )}
                                        {(dashboardGroup === 'Todos' || dashboardGroup === 'Cueva') && (
                                            <Area type="monotone" dataKey="cueva" stroke="#ff0099" strokeWidth={3} fillOpacity={1} fill="url(#colorCueva)" animationDuration={2500} animationEasing="ease-in-out" style={{ filter: 'drop-shadow(0 0 10px rgba(255, 0, 153, 0.5))' }} />
                                        )}
                                    </AreaChart>
                                </ResponsiveContainer>
                            </div>

                            <div className="overflow-x-auto max-h-[450px] scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-transparent">
                                <table className="w-full text-left text-sm">
                                    <thead className="bg-slate-950/90 text-slate-400 text-xs uppercase sticky top-0 z-10 backdrop-blur">
                                        <tr>
                                            <th className="p-4 text-center w-20 tracking-wider">Día</th>
                                            <th className="p-4 tracking-wider text-yellow-300">Barco</th>
                                            <th className="p-4 tracking-wider text-pink-300">Cueva</th>
                                            <th className="p-2 text-center text-[10px] text-yellow-400 font-bold uppercase tracking-tighter">M. Barco</th>
                                            <th className="p-2 text-center text-[10px] text-pink-400 font-bold uppercase tracking-tighter">M. Cueva</th>
                                            <th className="p-4 tracking-wider font-bold text-white">Total</th>
                                            <th className="p-4 text-right"></th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-800/50">
                                        {data.map((row: any) => (
                                            <tr key={row.id} className="group hover:bg-slate-800/60 transition-colors">
                                                <td className="p-3 text-center">
                                                    <span className="inline-block w-8 h-8 leading-8 rounded bg-slate-800/80 border border-slate-700 text-slate-200 font-mono font-bold shadow-inner">{row.dia}</span>
                                                </td>
                                                <td className="p-3 font-mono text-yellow-300 font-medium">{formatCurrency(row.barco)}</td>
                                                <td className="p-3 font-mono text-pink-400 font-medium">{formatCurrency(row.cueva)}</td>
                                                <td className="p-2 text-center font-mono text-yellow-500/70 font-bold text-xs">{row.mesasBarco || 0}</td>
                                                <td className="p-2 text-center font-mono text-pink-500/70 font-bold text-xs">{row.mesasCueva || 0}</td>
                                                <td className="p-3 font-mono font-bold text-white shadow-cyan-500/5">{formatCurrency(row.barco + row.cueva)}</td>
                                                <td className="p-3 text-right opacity-0 group-hover:opacity-100 transition-opacity">
                                                    <div className="flex justify-end gap-2 text-slate-500">
                                                        {row.isManual && (
                                                            <button
                                                                onClick={() => {
                                                                    const updated = data.map((d: any) => d.id === row.id ? { ...d, isManual: false } : d);
                                                                    setData(updated);
                                                                    setForceSyncCount(prev => prev + 1); // Forzar re-sincronización con DB
                                                                }}
                                                                className="p-1.5 hover:bg-emerald-500/10 rounded-lg text-emerald-500/60 hover:text-emerald-400 transition-colors"
                                                                title="Resetear a cálculo automático (DB)"
                                                            >
                                                                <RefreshCw size={14} />
                                                            </button>
                                                        )}
                                                        {role === 'admin' && (
                                                            <>
                                                                <button onClick={() => { setEditingItem(row); setOpForm({ dia: row.dia, barco: row.barco.toString(), cueva: row.cueva.toString(), mesasBarco: (row.mesasBarco || 0).toString(), mesasCueva: (row.mesasCueva || 0).toString() }); setActiveModal('operative') }} className="p-1.5 hover:bg-blue-500/20 rounded text-slate-500 hover:text-blue-400 transition-colors"><Edit2 size={16} /></button>
                                                                <button onClick={() => handleDeleteOp(row.id)} className="p-1.5 hover:bg-red-500/20 rounded text-slate-500 hover:text-red-400 transition-colors"><Trash2 size={16} /></button>
                                                            </>
                                                        )}
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                    <tfoot>
                                        <tr className="bg-slate-950/80 border-t-2 border-slate-700 font-bold text-sm sticky bottom-0 z-10 shadow-2xl">
                                            <td className="p-4 text-center text-slate-400 uppercase tracking-widest text-xs">Totales</td>
                                            <td className="p-4 font-mono text-yellow-300 text-base">{formatCurrency(totalBarco)}</td>
                                            <td className="p-4 font-mono text-pink-300 text-base">{formatCurrency(totalCueva)}</td>
                                            <td className="p-2 text-center font-mono text-yellow-400 text-xs">{data.reduce((sum, r) => sum + (r.mesasBarco || 0), 0)}</td>
                                            <td className="p-2 text-center font-mono text-pink-400 text-xs">{data.reduce((sum, r) => sum + (r.mesasCueva || 0), 0)}</td>
                                            <td className="p-4 font-mono text-white text-lg bg-emerald-500/10 border border-emerald-500/20 rounded shadow-[0_0_15px_rgba(16,185,129,0.2)]">{formatCurrency(totalBarco + totalCueva)}</td>
                                            <td></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>

                        {/* NÓMINA PRINCIPAL (DYNAMIC DB) */}
                        <div id="nomina-principal-section" className="bg-slate-900/60 backdrop-blur-xl border border-indigo-500/30 rounded-2xl overflow-hidden shadow-2xl relative scroll-mt-6">
                            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/10 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>
                            <div className="px-5 py-4 border-b border-indigo-500/20 flex justify-between items-center bg-slate-900/80">
                                <div className="flex items-center gap-4">
                                    <h2 className="font-bold text-indigo-300 flex items-center gap-2 text-sm uppercase tracking-widest">
                                        <div className="p-1.5 bg-indigo-500/20 rounded text-indigo-400"><Users size={16} /></div>
                                        NÓMINA PRINCIPAL: 9H = ${SHIFT_VALUE_USD} USD
                                    </h2>
                                    <div className="flex bg-slate-950/50 rounded-lg p-1 border border-indigo-500/20">
                                        {[1, 2].map(num => (
                                            <button key={num} onClick={() => setCurrentFortnight(num)} className={`px-4 py-1 text-[10px] font-bold uppercase rounded-md transition-all ${currentFortnight === num ? 'bg-indigo-600 text-white shadow-[0_0_10px_rgba(79,70,229,0.4)]' : 'text-slate-500 hover:text-indigo-400'}`}>
                                                {num === 1 ? '01-15' : '16-31'} {monthNames[selectedMonth].substring(0, 3).toUpperCase()}
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                {role === 'admin' && (
                                    <div className="flex gap-2">
                                        <button onClick={() => { setActiveModal('employee'); setEmployeeForm({ name: '', status: 'Activo', group: 'Barco', shift: 'Mañana' }); }} className="text-[10px] bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 px-3 py-1.5 rounded-lg border border-indigo-500/20 flex items-center gap-2 transition-all font-bold uppercase transition-all" title="Añadir nuevo empleado">
                                            <Plus size={14} /> AGREGAR STAFF
                                        </button>
                                        <button
                                            onClick={() => {
                                                syncEmployeesWithDB();
                                                alert("Nombres de empleados sincronizados con la Base de Datos Principal.");
                                            }}
                                            className="text-[10px] bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 px-3 py-1.5 rounded-lg border border-indigo-500/20 flex items-center gap-2 transition-all font-bold uppercase"
                                            title="Sincronizar nombres con DB Principal"
                                        >
                                            <RefreshCw size={14} /> SINCRONIZAR DB
                                        </button>
                                        <button
                                            onClick={() => {
                                                saveToCloud();
                                                alert("Cambios guardados en la Nómina Principal.");
                                            }}
                                            className="text-[10px] bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 px-3 py-1.5 rounded-lg border border-emerald-500/20 flex items-center gap-2 transition-all font-bold uppercase shadow-[0_0_15px_rgba(16,185,129,0.1)]"
                                            title="Guardar todos los registros de la nómina"
                                        >
                                            <Save size={14} /> GUARDAR CAMBIOS
                                        </button>
                                    </div>
                                )}
                            </div>

                            <div className="overflow-x-auto scrolbar-thin scrollbar-thumb-indigo-900/50">
                                <table className="w-full text-left text-xs border-collapse">
                                    <thead className="bg-slate-950/80 text-indigo-400/60 uppercase font-semibold">
                                        <tr>
                                            <th className="p-3 sticky left-0 z-20 bg-slate-950 border-r border-indigo-500/10 min-w-[150px]">Agente / Bando</th>
                                            {daysInFortnight.map(day => (
                                                <th key={day} className="p-2 text-center min-w-[45px] border-r border-indigo-500/10 text-slate-500">{day}</th>
                                            ))}
                                            <th className="p-3 text-center bg-indigo-500/5 text-indigo-300 min-w-[60px]">HRS</th>
                                            <th className="p-3 text-center bg-emerald-500/5 text-emerald-300 min-w-[80px]">NÓMINA</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-indigo-500/10 text-slate-300">
                                        {employees.filter((e: any) => dashboardGroup === 'Todos' || e.group === dashboardGroup).map((emp: any) => {
                                            const stats = calculateEmployeeStats(emp.id);
                                            return (
                                                <tr key={emp.id} className="group hover:bg-indigo-500/5 transition-colors">
                                                    <td className="p-3 sticky left-0 z-10 bg-slate-900/95 group-hover:bg-slate-900 border-r border-indigo-500/20 shadow-[5px_0_15px_rgba(0,0,0,0.5)]">
                                                        <div className="flex flex-col gap-1">
                                                            <div className="flex justify-between items-center">
                                                                <span className={`font-bold text-sm tracking-wide ${emp.status === 'Renunció' ? 'text-slate-500 line-through' : 'text-white'}`}>{emp.name}</span>
                                                                <span className={`text-[9px] px-1 rounded uppercase font-bold border ${emp.group === 'Barco' ? 'border-yellow-500/50 text-yellow-400 bg-yellow-500/10' : 'border-pink-500/50 text-pink-400 bg-pink-500/10'}`}>{emp.group || '?'}</span>
                                                            </div>

                                                            {/* SHIFT & STATUS ROW */}
                                                            <div className="flex items-center gap-1.5 flex-wrap">
                                                                <select disabled={role !== 'admin'} value={emp.shift || 'Mañana'} onChange={(e) => { const updated = { ...emp, shift: e.target.value }; setEmployees(employees.map((em: any) => em.id === emp.id ? updated : em)); }} className="bg-slate-950/50 rounded px-1 py-0.5 text-[9px] uppercase font-bold border border-slate-700 text-slate-400 outline-none cursor-pointer hover:border-indigo-500/30 disabled:opacity-50 disabled:cursor-not-allowed">
                                                                    <option value="Mañana">☀️ Mañ</option>
                                                                    <option value="Noche">🌙 Noc</option>
                                                                    <option value="Franquero">🔄 Fran</option>
                                                                </select>

                                                                <select disabled={role !== 'admin'} value={emp.status} onChange={(e) => { const updated = { ...emp, status: e.target.value }; setEmployees(employees.map((em: any) => em.id === emp.id ? updated : em)); }} className={`bg-slate-950/50 rounded px-1 py-0.5 text-[9px] uppercase font-bold border border-slate-700 outline-none cursor-pointer flex-1 ${emp.status === 'Activo' ? 'text-emerald-400 border-emerald-500/30' : emp.status === 'Ausente' ? 'text-red-400 border-red-500/30' : emp.status === 'Renunció' ? 'text-slate-500 border-slate-600' : 'text-blue-400 border-blue-500/30'} disabled:opacity-50 disabled:cursor-not-allowed`}>
                                                                    <option value="Activo">Activo</option>
                                                                    <option value="Ausente">Ausente</option>
                                                                    <option value="Suplente">Suplente</option>
                                                                    <option value="Renunció">Renunció</option>
                                                                </select>
                                                            </div>

                                                            <div className="flex justify-end opacity-0 group-hover:opacity-100 transition-opacity gap-1 mt-0.5">
                                                                {role === 'admin' && (
                                                                    <>
                                                                        <button onClick={() => { setActiveModal('employee'); setEditingItem(emp); setEmployeeForm({ name: emp.name, status: emp.status, group: emp.group || 'Barco', shift: emp.shift || 'Mañana' }) }} className="text-slate-600 hover:text-indigo-400"><Edit2 size={12} /></button>
                                                                        <button onClick={() => handleDeleteEmployee(emp.id)} className="text-slate-600 hover:text-pink-400"><Trash2 size={12} /></button>
                                                                    </>
                                                                )}
                                                            </div>
                                                        </div>
                                                    </td>
                                                    {daysInFortnight.map(day => {
                                                        const hasNote = shiftsNotes[emp.id]?.[day];
                                                        const detail = shiftsMatrix[emp.id]?.[day];
                                                        const isPresent = detail && typeof detail === 'object' ? parseFloat(detail.horas) > 0 : parseFloat(detail) > 0;

                                                        return (
                                                            <td key={day} className="p-0 border-r border-indigo-500/10 text-center relative group/cell">
                                                                <div
                                                                    onClick={() => {
                                                                        if (role !== 'admin') return;
                                                                        const existing = shiftsMatrix[emp.id]?.[day] || {};
                                                                        const defaultDetail = typeof existing === 'object' ? existing : { entrada: '', salida: '', horas: existing, estatus: parseFloat(existing) > 0 ? 'Presente' : 'Falta' };
                                                                        setShiftDetailForm(defaultDetail);
                                                                        setActiveShiftDay({ empId: emp.id, day });
                                                                        setActiveModal('shiftDetail');
                                                                    }}
                                                                    className={`w-full h-full py-4 text-center cursor-pointer font-mono font-bold transition-all flex flex-col items-center justify-center ${isPresent ? 'text-emerald-400 bg-emerald-500/5' : 'text-slate-600'} hover:bg-white/5`}
                                                                >
                                                                    <span>{getShiftValue(emp.id, day) || '.'}</span>
                                                                </div>
                                                                {hasNote && (
                                                                    <div className="absolute top-1 right-1 w-1 h-1 rounded-full bg-purple-500 shadow-[0_0_5px_#a855f7]"></div>
                                                                )}
                                                            </td>
                                                        );
                                                    })}
                                                    <td className="p-2 text-center font-mono font-bold text-indigo-300 bg-indigo-500/5">{formatNumber(stats.totalHours)}</td>
                                                    <td className="p-2 text-center font-mono font-bold text-emerald-400 bg-emerald-500/5 text-sm">{formatUSD(stats.totalPayUSD)} S</td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                            <div className="bg-slate-900/40 p-3 border-t border-indigo-500/20 flex justify-between items-center">
                                <span className="text-slate-400 text-xs font-bold uppercase tracking-widest">Total Staff (Sin Felipe)</span>
                                <span className="text-indigo-400 font-mono font-bold">{formatUSD(employees.reduce((acc: number, emp: any) => acc + calculateEmployeeStats(emp.id).totalPayUSD, 0))}</span>
                            </div>
                        </div>

                        {/* --- FELIPE SUPERVISOR SECTION --- */}
                        {/* --- FELIPE SUPERVISOR SECTION --- */}
                        <div className="bg-gradient-to-r from-slate-900 to-indigo-950/30 backdrop-blur-xl border border-indigo-500/30 rounded-2xl p-5 relative overflow-hidden shadow-2xl group transition-all hover:border-indigo-500/50">
                            {/* CLEAN BACKGROUND, NO NOISE */}
                            <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-purple-500/5 opacity-50"></div>
                            <div className="absolute -right-4 -top-4 w-20 h-20 bg-indigo-500/20 rounded-full blur-xl"></div>

                            <div className="flex justify-between items-center relative z-10">
                                <div>
                                    <h3 className="text-indigo-300 font-bold uppercase tracking-widest text-xs mb-1 flex items-center gap-2">
                                        <div className="p-1 bg-indigo-500/20 rounded"><Users size={14} /></div>
                                        SUPERVISOR
                                    </h3>
                                    <div className="text-2xl font-bold text-white tracking-tight">Felipe</div>
                                    <div className="text-[10px] text-slate-400 font-mono mt-1">TARIFA: $28.84 / DÍA</div>
                                </div>

                                <div className="flex flex-col md:flex-row bg-slate-950/40 rounded-xl p-3 border border-indigo-500/20 items-end gap-5">
                                    <div className="flex flex-col items-center">
                                        <label className="text-[10px] text-slate-500 font-bold uppercase mb-1">Normales</label>
                                        <div className="flex items-center gap-2">
                                            <input
                                                type="number"
                                                disabled={role !== 'admin'}
                                                className="w-12 bg-slate-900 border border-slate-700 rounded-lg py-2 px-1 text-center text-white font-bold focus:ring-2 focus:ring-indigo-500 outline-none"
                                                value={felipeDays}
                                                onChange={(e) => setFelipeDays(Number(e.target.value))}
                                            />
                                            {role === 'admin' && <button onClick={() => setFelipeDays(daysInFortnight.length)} className="text-[9px] bg-indigo-500/20 hover:bg-indigo-500 px-1.5 py-1 rounded text-indigo-300 hover:text-white transition-colors">FULL</button>}
                                        </div>
                                    </div>

                                    {/* SECCIÓN DÍAS LIBRES SEPARADA VISUALMENTE */}
                                    <div className="flex flex-col items-center gap-1 bg-indigo-500/5 p-2 rounded-lg border border-indigo-500/10">
                                        <label className="text-[9px] text-indigo-300/60 font-bold uppercase tracking-widest border-b border-indigo-500/10 pb-1 w-full text-center">DÍAS LIBRES</label>
                                        <div className="flex gap-2">
                                            <div className="flex flex-col items-center">
                                                <label className="text-[8px] text-blue-400/50 uppercase">Asig.</label>
                                                <input
                                                    type="number"
                                                    disabled={role !== 'admin'}
                                                    className="w-10 bg-slate-900/50 border border-blue-500/20 rounded py-1 px-1 text-center text-blue-300 text-xs focus:ring-1 focus:ring-blue-500 outline-none"
                                                    value={felipeAssignedFreeDays}
                                                    onChange={(e) => setFelipeAssignedFreeDays(Number(e.target.value))}
                                                />
                                            </div>
                                            <div className="flex flex-col items-center">
                                                <label className="text-[8px] text-emerald-400/50 uppercase">Trab.</label>
                                                <input
                                                    type="number"
                                                    disabled={role !== 'admin'}
                                                    className="w-10 bg-slate-900 border border-emerald-500/40 rounded py-1 px-1 text-center text-emerald-400 font-bold text-lg focus:ring-1 focus:ring-emerald-500 outline-none shadow-[0_0_10px_rgba(16,185,129,0.1)]"
                                                    value={felipeExtraDays}
                                                    onChange={(e) => setFelipeExtraDays(Number(e.target.value))}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            {/* --- SECCIÓN ADELANTOS FELIPE --- */}
                            <div className="mt-4 bg-slate-950/40 rounded-xl p-4 border border-indigo-500/20 relative z-10">
                                <div className="flex justify-between items-center mb-3">
                                    <h4 className="text-[10px] text-indigo-300 font-bold uppercase tracking-widest flex items-center gap-2">
                                        <div className="w-1.5 h-1.5 rounded-full bg-indigo-500"></div> LISTADO DE ADELANTOS
                                    </h4>
                                    {role === 'admin' && (
                                        <button
                                            onClick={() => {
                                                setEditingItem(null);
                                                setFelipeAdvanceForm({ motivo: '', monto: '' });
                                                setActiveModal('felipe_advance');
                                            }}
                                            className="text-[9px] bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 px-2 py-1 rounded border border-indigo-500/30 flex items-center gap-1 transition-colors"
                                        >
                                            <Plus size={10} /> AGREGAR ADELANTO
                                        </button>
                                    )}
                                </div>

                                <div className="space-y-1 mb-3">
                                    {(felipeAdvances || []).length === 0 ? (
                                        <div className="text-center py-2 text-slate-600 text-[10px] italic">No hay adelantos registrados</div>
                                    ) : (
                                        (felipeAdvances || []).map((adv: any) => (
                                            <div key={adv.id} className="flex justify-between items-center text-xs bg-slate-900/50 p-2 rounded border border-indigo-500/10 group hover:border-indigo-500/30 transition-colors">
                                                <span className="text-slate-400 font-medium">{adv.motivo}</span>
                                                <div className="flex items-center gap-3">
                                                    <span className="text-red-300 font-mono font-bold">- {formatUSD(adv.monto)}</span>
                                                    {role === 'admin' && (
                                                        <button
                                                            onClick={() => handleDeleteFelipeAdvance(adv.id)}
                                                            className="text-slate-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                                                        >
                                                            <Trash2 size={10} />
                                                        </button>
                                                    )}
                                                </div>
                                            </div>
                                        ))
                                    )}
                                </div>

                                <div className="flex justify-between items-center pt-2 border-t border-slate-800">
                                    <span className="text-[10px] text-slate-500 font-bold uppercase">Total Descuentos</span>
                                    <span className="text-sm text-red-400 font-mono font-bold">
                                        - {formatUSD((felipeAdvances || []).reduce((acc: number, cur: any) => acc + (cur.monto || 0), 0))}
                                    </span>
                                </div>
                            </div>

                            <div className="mt-4 text-right bg-emerald-500/5 p-3 rounded-xl border border-emerald-500/10 min-w-[120px]">
                                <div className="text-[9px] text-emerald-400/60 font-bold uppercase mb-1">Total a Pagar (Neto)</div>
                                <div className="text-2xl font-mono font-bold text-emerald-400 drop-shadow-[0_0_10px_rgba(52,211,153,0.3)]">
                                    {formatUSD(
                                        ((felipeDays + felipeExtraDays) * 28.84) -
                                        ((felipeAdvances || []).reduce((acc: number, cur: any) => acc + (cur.monto || 0), 0))
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* TOTAL GENERAL NOMINA */}
                        <div className="bg-slate-900/60 backdrop-blur-xl border border-emerald-500/30 rounded-2xl p-6 shadow-2xl relative overflow-hidden group">
                            <div className="absolute top-0 right-0 p-4 opacity-5 text-emerald-500"><Landmark size={60} /></div>

                            <h3 className="text-xs font-bold uppercase text-emerald-400 tracking-widest flex items-center gap-2 mb-6">
                                <div className="p-1.5 bg-emerald-500/20 rounded-lg text-emerald-400"><Medal size={16} /></div>
                                RESUMEN DE PAGO TOTAL
                            </h3>

                            <div className="space-y-3 mb-6">
                                <div className="flex justify-between items-center text-sm">
                                    <span className="text-slate-500 font-bold">STAFF (AGENTES)</span>
                                    <span className="text-white font-mono font-bold">{formatUSD(staffTotalUSD)}</span>
                                </div>
                                <div className="flex justify-between items-center text-sm">
                                    <span className="text-slate-500 font-bold">SUPERVISOR (FELIPE)</span>
                                    <span className="text-white font-mono font-bold">{formatUSD(felipeTotalUSD)}</span>
                                </div>

                                {/* SUBTOTAL NÓMINA */}
                                <div className="flex justify-between items-center py-2 border-y border-slate-800/50 my-2">
                                    <span className="text-emerald-400 font-bold text-xs uppercase tracking-widest">Subtotal Nómina</span>
                                    <span className="text-emerald-400 font-mono font-bold">{formatUSD(subTotalPayrollUSD)}</span>
                                </div>

                                {/* SECCION PUBLICIDAD POR GRUPO */}
                                <div className="space-y-4 pt-2 border-t border-slate-800/30 mt-2">
                                    <div className="flex items-center justify-between mb-2">
                                        <div className="flex items-center gap-2">
                                            <span className="text-blue-400 font-bold uppercase text-[10px] tracking-widest text-left">Inversión Publicidad (FMX Sync)</span>
                                            <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></div>
                                        </div>

                                        {/* TOGGLE SUMA PUBLICIDAD */}
                                        <button
                                            onClick={() => {
                                                const newVal = !includePublicityInTotal;
                                                setIncludePublicityInTotal(newVal);
                                                localStorage.setItem('includePublicityInTotal', JSON.stringify(newVal));
                                            }}
                                            className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border transition-all ${includePublicityInTotal ? 'bg-blue-500/20 border-blue-500/40 text-blue-300' : 'bg-slate-800 border-slate-700 text-slate-500'}`}
                                            title={includePublicityInTotal ? "Suma activa al total final" : "Suma desactivada"}
                                        >
                                            <div className={`w-3 h-3 rounded-full flex items-center justify-center border ${includePublicityInTotal ? 'border-blue-400 bg-blue-500 shadow-[0_0_8px_#3b82f6]' : 'border-slate-500'}`}>
                                                {includePublicityInTotal && <CheckCircle2 size={10} className="text-white" />}
                                            </div>
                                            <span className="text-[9px] font-black uppercase tracking-tighter">
                                                {includePublicityInTotal ? 'SUMAR' : 'IGNORAR'}
                                            </span>
                                        </button>
                                    </div>

                                    {(dashboardGroup === 'Todos' || dashboardGroup === 'Barco') && (
                                        <div className="flex justify-between items-center text-sm pl-2 border-l-2 border-emerald-500/30">
                                            <div className="flex flex-col">
                                                <span className="text-slate-500 font-bold text-[10px]">EL BARCO</span>
                                                <span className="text-[8px] text-slate-600 font-mono">Q: {formatCurrency(totalFortnightPubARS_Barco)}</span>
                                            </div>
                                            <span className="text-white font-mono font-bold">{formatUSD(totalFortnightPubUSD_Barco)}</span>
                                        </div>
                                    )}

                                    {(dashboardGroup === 'Todos' || dashboardGroup === 'Cueva') && (
                                        <div className="flex justify-between items-center text-sm pl-2 border-l-2 border-orange-500/30">
                                            <div className="flex flex-col">
                                                <span className="text-slate-500 font-bold text-[10px]">LA CUEVA</span>
                                                <span className="text-[8px] text-slate-600 font-mono">Q: {formatCurrency(totalFortnightPubARS_Cueva)}</span>
                                            </div>
                                            <span className="text-white font-mono font-bold">{formatUSD(totalFortnightPubUSD_Cueva)}</span>
                                        </div>
                                    )}

                                    {dashboardGroup === 'Todos' && (
                                        <div className="flex justify-between items-center py-2 bg-blue-500/5 px-3 rounded-xl border border-blue-500/10">
                                            <div className="flex flex-col">
                                                <span className="text-blue-400 font-black text-[10px] uppercase">Total Publicidad</span>
                                                <div className="flex items-center gap-2">
                                                    <span className="text-[9px] text-slate-400 font-mono">ARS: {formatCurrency(totalFortnightPubARS_Total)}</span>
                                                    <span className="text-[9px] text-slate-400 font-bold">• Mes: {formatUSD(totalMonthPubUSD_Total)}</span>
                                                </div>
                                            </div>
                                            <span className="text-blue-400 font-mono font-black text-lg">{formatUSD(totalFortnightPubUSD_Total)}</span>
                                        </div>
                                    )}
                                    <span className="text-[8px] text-blue-500/40 font-bold uppercase tracking-tighter block italic text-center">Datos sincronizados en tiempo real por grupo</span>
                                </div>
                            </div>

                            <div className="pt-4 border-t border-emerald-500/20 flex justify-between items-end">
                                <div>
                                    <span className="text-emerald-400/80 text-[10px] font-bold uppercase tracking-[0.2em] block mb-1">Total Final a Liquidar</span>
                                    <div className="text-3xl font-mono font-bold text-emerald-400 drop-shadow-[0_0_15px_rgba(52,211,153,0.4)]">
                                        {formatUSD(grandTotalUSD)}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* RIGHT COLUMN */}
                    <div className="space-y-6">

                        {/* --- EXCLUSIVE ADMIN CENTER --- */}
                        {isAdminOrVice && (
                            <div className="space-y-6 animate-in slide-in-from-right duration-700">

                                {/* MONITOREO DE SEGURIDAD (NEW: RESTRICCIONES) */}
                                <div className="bg-slate-900/60 backdrop-blur-xl border border-rose-500/30 rounded-2xl p-6 shadow-2xl relative overflow-hidden group hover:border-rose-500/50 transition-all cursor-pointer" onClick={onNavigateToRestriccion}>
                                    <div className="absolute top-0 right-0 p-4 opacity-5 text-rose-500 group-hover:scale-110 transition-transform"><ShieldAlert size={60} /></div>
                                    <h3 className="text-xs font-bold uppercase text-rose-400 tracking-widest flex items-center gap-2 mb-4">
                                        <div className="p-1.5 bg-rose-500/20 rounded-lg text-rose-500">
                                            <ShieldAlert size={16} />
                                        </div>
                                        CENTRO DE SEGURIDAD
                                    </h3>
                                    <div className="space-y-4">
                                        <div>
                                            <h4 className="text-white font-black text-lg uppercase italic tracking-tighter">RESTRICCIÓN & LISTA NEGRA</h4>
                                            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Control de clientes y advertencias</p>
                                        </div>
                                        <button
                                            className="w-full py-3 bg-rose-600/10 hover:bg-rose-600 text-rose-500 hover:text-white border border-rose-500/20 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all"
                                        >
                                            ENTRAR AL MÓDULO
                                        </button>
                                    </div>
                                </div>

                                {/* MONITOR DE USUARIOS ONLINE (Admin & Vice) */}
                                <div className="bg-slate-900/60 backdrop-blur-xl border border-blue-500/20 rounded-2xl p-5 shadow-2xl relative overflow-hidden group hover:border-blue-500/40 transition-all">
                                    <div className="absolute -right-6 -top-6 w-20 h-20 bg-blue-500/10 rounded-full blur-2xl group-hover:bg-blue-500/20 transition-all"></div>
                                    <h3 className="text-xs font-bold uppercase text-blue-400 tracking-widest flex items-center justify-between mb-4">
                                        <div className="flex items-center gap-2">
                                            <div className="p-1.5 bg-blue-500/20 rounded-lg text-blue-400">
                                                <Users size={16} />
                                            </div>
                                            USUARIOS ONLINE
                                        </div>
                                        <div className="flex items-center gap-1.5">
                                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                                            <span className="text-[10px] text-emerald-400 font-mono">{onlineUsers.length} ACTIVOS</span>
                                        </div>
                                    </h3>

                                    <div className="space-y-3 max-h-[160px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-blue-900/30">
                                        {onlineUsers.length === 0 ? (
                                            <div className="text-center py-4 text-slate-500 italic text-[10px]">No hay sesiones activas</div>
                                        ) : (
                                            onlineUsers.map((session, idx) => (
                                                <div key={idx} className="flex justify-between items-center p-2.5 rounded-xl bg-slate-950/40 border border-slate-800/50 group/item hover:border-blue-500/30 transition-all">
                                                    <div className="flex items-center gap-2.5">
                                                        <div className="w-7 h-7 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-400 border border-blue-500/20">
                                                            <User size={14} />
                                                        </div>
                                                        <div className="flex flex-col">
                                                            <span className="text-xs font-bold text-white leading-none capitalize">
                                                                {session.user_email} {session.user_email === userEmail && <span className="text-[10px] text-blue-400 font-black ml-1">(YO)</span>}
                                                            </span>
                                                            <span className="text-[8px] text-slate-500 uppercase tracking-tighter mt-1 font-mono">Dispositivo: {session.device_id.substring(0, 8)}...</span>
                                                        </div>
                                                    </div>
                                                    <div className="flex items-center gap-3">
                                                        <div className="text-[9px] text-blue-400/60 font-mono font-bold">LIVE</div>
                                                        {isOnlyAdmin && session.user_email !== userEmail && (
                                                            <button
                                                                onClick={() => handleKickUser(session.user_email, session.device_id)}
                                                                className="p-1.5 hover:bg-red-500/20 rounded text-slate-500 hover:text-red-400 transition-colors"
                                                                title="Forzar Cierre de Sesión"
                                                            >
                                                                <X size={12} />
                                                            </button>
                                                        )}
                                                    </div>
                                                </div>
                                            ))
                                        )}
                                    </div>
                                </div>

                                {/* GESTIÓN DE APROBACIONES (ADMIN ONLY) */}
                                {isOnlyAdmin && (
                                    <div className="bg-slate-900/60 backdrop-blur-xl border border-amber-500/20 rounded-2xl p-5 shadow-2xl relative overflow-hidden group hover:border-amber-500/40 transition-all">
                                        <h3 className="text-xs font-bold uppercase text-amber-400 tracking-widest flex items-center gap-2 mb-4">
                                            <div className="p-1.5 bg-amber-500/20 rounded-lg text-amber-400">
                                                <Lock size={16} />
                                            </div>
                                            SOLICITUDES DE ACCESO
                                        </h3>

                                        <div className="space-y-3">
                                            {pendingApprovals.length === 0 ? (
                                                <div className="text-center py-4 text-slate-500 italic text-[10px]">Sin solicitudes pendientes</div>
                                            ) : (
                                                pendingApprovals.map((req) => (
                                                    <div key={req.id} className="p-3 rounded-xl bg-slate-950/60 border border-amber-500/20 space-y-3">
                                                        <div className="flex justify-between items-start">
                                                            <div className="flex flex-col">
                                                                <span className="text-sm font-black text-white">{req.username}</span>
                                                                <span className="text-[9px] text-slate-400 uppercase font-bold tracking-tighter">{req.nombre} • Rol: {req.role}</span>
                                                            </div>
                                                            <div className="bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded text-[8px] font-black uppercase ring-1 ring-amber-500/20">Pendiente</div>
                                                        </div>
                                                        <div className="grid grid-cols-2 gap-2">
                                                            <button
                                                                onClick={() => handleApproveUser(req.id)}
                                                                className="flex items-center justify-center gap-1.5 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 rounded-lg text-[9px] font-black transition-all hover:scale-[1.02] active:scale-95"
                                                            >
                                                                APROBAR
                                                            </button>
                                                            <button
                                                                onClick={() => handleDenyUser(req.id)}
                                                                className="flex items-center justify-center gap-1.5 py-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 rounded-lg text-[9px] font-black transition-all hover:scale-[1.02] active:scale-95"
                                                            >
                                                                DENEGAR
                                                            </button>
                                                        </div>
                                                    </div>
                                                ))
                                            )}
                                        </div>
                                    </div>
                                )}
                            </div>
                        )}


                        {/* SALDO JUGADORES */}
                        <div className="bg-slate-900/60 backdrop-blur-xl border border-pink-500/20 rounded-2xl p-5 space-y-4 hover:border-pink-500/40 transition-colors shadow-2xl relative overflow-hidden">
                            <div className="absolute -right-10 -top-10 w-32 h-32 bg-pink-500/10 rounded-full blur-2xl pointer-events-none"></div>
                            <h3 className="text-xs font-bold uppercase text-pink-400 tracking-widest flex items-center gap-2 mb-4">
                                <div className="p-1 bg-pink-500/20 rounded"><User size={12} /></div> SALDOS JUGADORES
                            </h3>
                            {players.map((p: any) => (
                                <div key={p.id} className={`flex justify-between items-center p-4 rounded-xl bg-slate-950/40 border border-slate-800 hover:border-${p.tipo === 'barco' ? 'yellow' : 'pink'}-500/50 transition-all group hover:shadow-[0_0_15px_rgba(${p.tipo === 'barco' ? '234,179,8' : '236,72,153'},0.1)]`}>
                                    <div className="flex items-center gap-3">
                                        <div className={`p-2 rounded-lg ${p.tipo === 'barco' ? 'bg-yellow-500/10 text-yellow-400' : 'bg-fuchsia-500/10 text-fuchsia-400'}`}>
                                            {p.tipo === 'barco' ? <Ship size={18} /> : <Mountain size={18} />}
                                        </div>
                                        <span className="font-bold text-sm tracking-wide text-slate-200">{p.nombre}</span>
                                    </div>
                                    <button onClick={() => { if (role === 'admin') { setActiveModal('player'); setEditingItem(p); setPlayerForm({ nombre: p.nombre, saldo: p.saldo }) } }} className={`flex items-center gap-3 ${role === 'admin' ? 'group-hover:scale-105 cursor-pointer' : 'cursor-default'} transition-transform`}>
                                        <span className={`font-mono font-bold text-lg ${p.saldo < 0 ? 'text-red-400 drop-shadow-[0_0_5px_rgba(248,113,113,0.5)]' : 'text-emerald-400 drop-shadow-[0_0_5px_rgba(52,211,153,0.5)]'}`}>{formatCurrency(p.saldo)}</span>
                                    </button>
                                </div>
                            ))}
                        </div>

                        {/* BANCOS */}
                        <div className="bg-slate-900/60 backdrop-blur-xl border border-emerald-500/20 rounded-2xl p-5 hover:border-emerald-500/40 transition-colors shadow-2xl">
                            <div className="flex justify-between items-center mb-4">
                                <h3 className="text-xs font-bold uppercase text-emerald-400 tracking-widest flex items-center gap-2">
                                    <div className="p-1 bg-emerald-500/20 rounded"><Landmark size={12} /></div> BANCOS & CAJAS
                                </h3>
                                <button onClick={() => { if (role === 'admin') { setActiveModal('bank'); setEditingItem(null); setBankForm({ nombre: '', monto: '' }) } }} className={`text-emerald-500/50 ${role === 'admin' ? 'hover:text-emerald-400' : 'opacity-0 cursor-default'}`}><PlusCircle size={16} /></button>
                            </div>
                            <div className="space-y-2">
                                {banks.map((b: any) => (
                                    <div key={b.id} className="flex justify-between items-center p-3 rounded-lg bg-slate-950/30 border border-transparent hover:border-emerald-500/30 hover:bg-slate-950/60 group transition-all">
                                        <span className="text-slate-400 text-sm font-medium pl-2 border-l-2 border-slate-700 group-hover:border-emerald-500 transition-colors">{b.nombre}</span>
                                        <div className="flex items-center gap-3">
                                            <span className="font-mono text-white font-bold">{formatCurrency(b.monto)}</span>
                                            <div className="flex opacity-0 group-hover:opacity-100 transition-opacity gap-1">
                                                {role === 'admin' && (
                                                    <>
                                                        <button onClick={() => { setActiveModal('bank'); setEditingItem(b); setBankForm({ nombre: b.nombre, monto: b.monto }) }} className="p-1 hover:bg-slate-700 rounded text-slate-500 hover:text-white"><Edit2 size={12} /></button>
                                                        <button onClick={() => handleDeleteBank(b.id)} className="p-1 hover:bg-red-900/20 rounded text-slate-500 hover:text-red-400"><Trash2 size={12} /></button>
                                                    </>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* ENVIOS LIST */}
                        <div className="bg-slate-900/60 backdrop-blur-xl border border-purple-500/20 rounded-2xl overflow-hidden shadow-2xl">
                            <div className="p-4 border-b border-purple-500/10 flex justify-between items-center bg-slate-950/40">
                                <h3 className="text-xs font-bold uppercase text-purple-400 tracking-widest flex items-center gap-2">
                                    <div className="p-1 bg-purple-500/20 rounded"><Send size={12} /></div> ENVÍOS
                                </h3>
                                <button onClick={() => { if (role === 'admin') { setActiveModal('shipment'); setEditingItem(null); setShipForm({ fecha: '', monto: '', nota: '', comprobante: '' }) } }} className={`text-purple-400/50 ${role === 'admin' ? 'hover:text-purple-300' : 'opacity-0 cursor-default'}`}><PlusCircle size={16} /></button>
                            </div>
                            <div className="max-h-[350px] overflow-y-auto scrollbar-thin scrollbar-thumb-purple-900/30">
                                <table className="w-full text-xs text-left">
                                    <tbody className="divide-y divide-purple-500/10">
                                        {shipments.map((s: any) => (
                                            <tr key={s.id} className="hover:bg-purple-500/5 transition-colors group">
                                                <td className="p-3 text-purple-200 font-medium">{s.fecha}</td>
                                                <td className="p-3 font-mono text-white text-sm">{formatCurrency(s.monto)}</td>
                                                <td className="p-3 flex items-center justify-end gap-2">
                                                    {s.comprobante && (
                                                        <a
                                                            href={s.comprobante}
                                                            target="_blank"
                                                            rel="noopener noreferrer"
                                                            className="p-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 rounded transition-all"
                                                            title="Ver Comprobante"
                                                        >
                                                            <Upload size={12} />
                                                        </a>
                                                    )}
                                                    {s.nota && (
                                                        <span className="px-1.5 py-0.5 rounded border border-purple-500/30 bg-purple-500/10 text-purple-300 text-[10px] font-bold uppercase">
                                                            {s.nota}
                                                        </span>
                                                    )}
                                                    <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                                        {role === 'admin' && (
                                                            <>
                                                                <button onClick={() => { setActiveModal('shipment'); setEditingItem(s); setShipForm({ fecha: s.fecha, monto: s.monto, nota: s.nota, comprobante: s.comprobante || '' }) }} className="text-slate-500 hover:text-white"><Edit2 size={12} /></button>
                                                                <button onClick={() => handleDeleteShip(s.id)} className="text-slate-500 hover:text-red-400"><Trash2 size={12} /></button>
                                                            </>
                                                        )}
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>

                            {/* TOTAL FOOTER (NUEVO) */}
                            <div className="p-4 bg-purple-500/5 border-t border-purple-500/20 flex justify-between items-center bg-slate-950/40">
                                <div className="flex flex-col">
                                    <span className="text-[10px] text-purple-400 font-black uppercase tracking-[0.2em]">Total Acumulado</span>
                                    <span className="text-[8px] text-slate-500 font-bold uppercase tracking-widest leading-none mt-0.5">Control de Envíos</span>
                                </div>
                                <div className="text-right">
                                    <span className="text-xl font-mono font-black text-white drop-shadow-[0_0_15px_rgba(168,85,247,0.4)]">
                                        {formatCurrency(totalEnviado)}
                                    </span>
                                </div>
                            </div>
                        </div>

                        {/* TOP 3 PERFORMANCE WIDGET */}
                        <div className="bg-slate-900/60 backdrop-blur-xl border border-yellow-500/20 rounded-2xl p-5 shadow-2xl relative overflow-hidden group hover:border-yellow-500/40 transition-all duration-500">
                            <div className="absolute -right-6 -top-6 w-24 h-24 bg-yellow-500/10 rounded-full blur-2xl group-hover:bg-yellow-500/20 transition-all"></div>
                            <h3 className="text-xs font-bold uppercase text-yellow-500 tracking-widest flex items-center justify-between mb-6">
                                <div className="flex items-center gap-2">
                                    <div className="p-1.5 bg-yellow-500/20 rounded-lg text-yellow-500">
                                        <Trophy size={16} />
                                    </div>
                                    TOP RENDIMIENTO
                                </div>
                                <span className="text-[10px] text-slate-500 font-mono">HRS QUINCENA</span>
                            </h3>

                            <div className="space-y-6">
                                {topEmployees.length === 0 ? (
                                    <div className="text-center py-8 text-slate-600 italic text-xs">Sin registros esta quincena</div>
                                ) : (
                                    topEmployees.map((emp: any, idx: number) => (
                                        <div key={idx} className="relative">
                                            <div className="flex justify-between items-end mb-2">
                                                <div className="flex items-center gap-2">
                                                    <div className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-[10px] ${idx === 0 ? 'bg-yellow-500 text-black' : idx === 1 ? 'bg-slate-300 text-black' : 'bg-amber-700 text-white'}`}>
                                                        {idx + 1}
                                                    </div>
                                                    <div className="flex flex-col">
                                                        <span className="text-sm font-bold text-white tracking-wide">{emp.name}</span>
                                                        <span className={`text-[9px] font-bold uppercase tracking-widest ${emp.group === 'Barco' ? 'text-yellow-400' : 'text-fuchsia-400'}`}>{emp.group}</span>
                                                    </div>
                                                </div>
                                                <div className="text-right">
                                                    <div className="text-lg font-mono font-bold text-white leading-none">{emp.stats.totalHours.toFixed(1)}</div>
                                                    <div className="text-[9px] text-slate-500 font-bold uppercase mt-1">Acumuladas</div>
                                                </div>
                                            </div>

                                            {/* PROGRESS BAR */}
                                            <div className="h-2 w-full bg-slate-800/50 rounded-full overflow-hidden border border-white/5">
                                                <div
                                                    className={`h-full rounded-full transition-all duration-1000 ease-out shadow-[0_0_10px_rgba(255,255,255,0.1)] ${idx === 0 ? 'bg-gradient-to-r from-yellow-600 to-yellow-300' : idx === 1 ? 'bg-gradient-to-r from-slate-500 to-slate-200' : 'bg-gradient-to-r from-amber-800 to-amber-500'}`}
                                                    style={{ width: `${(emp.stats.totalHours / maxHours) * 100}%` }}
                                                ></div>
                                            </div>

                                            {idx === 0 && (
                                                <div className="absolute -left-1 top-0 bottom-0 w-[2px] bg-yellow-400 shadow-[0_0_10px_#eab308] opacity-50"></div>
                                            )}
                                        </div>
                                    ))
                                )}
                            </div>

                            <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
                                <div className="flex items-center gap-1.5 grayscale opacity-50">
                                    <Medal size={14} className="text-slate-400" />
                                    <span className="text-[10px] text-slate-500 font-bold uppercase tracking-tighter">Merito Operativo</span>
                                </div>
                                <div className="text-[10px] text-yellow-500/50 font-mono italic">
                                    v3.1 Algorithm
                                </div>
                            </div>
                        </div>

                        {/* --- PUBLICIDAD SECTION (MOVED UP) --- */}
                        <div className="bg-slate-900/60 backdrop-blur-xl border border-emerald-500/20 rounded-2xl p-5 shadow-2xl relative overflow-hidden group hover:border-emerald-500/30 transition-all">
                            <div className="absolute top-0 right-0 p-4 opacity-5 text-emerald-500"><Activity size={40} /></div>
                            <h3 className="text-xs font-bold uppercase text-emerald-400 tracking-widest flex items-center gap-2 mb-6">
                                <div className="p-1.5 bg-emerald-500/20 rounded-lg text-emerald-400"><Activity size={16} /></div>
                                CONTROL PUBLICIDAD
                            </h3>

                            <div className="space-y-6">
                                {/* CALENDARIO PUBLICIDAD (FULL MONTH) */}
                                <div className="space-y-4">
                                    <div className="flex justify-between items-center px-1">
                                        <div className="flex items-center gap-3">
                                            <div className="flex items-center gap-1 bg-black/40 p-1 rounded-lg border border-white/5">
                                                <button onClick={() => { if (pubMonth === 0) { setPubMonth(11); setPubYear(y => y - 1); } else setPubMonth(m => m - 1); }} className="p-1 hover:bg-white/5 rounded text-slate-500 hover:text-white transition-all"><ChevronLeft size={14} /></button>
                                                <span className="text-[9px] font-black uppercase text-white w-20 text-center">{monthNames[pubMonth]} {pubYear}</span>
                                                <button onClick={() => { if (pubMonth === 11) { setPubMonth(0); setPubYear(y => y + 1); } else setPubMonth(m => m + 1); }} className="p-1 hover:bg-white/5 rounded text-slate-500 hover:text-white transition-all"><ChevronRight size={14} /></button>
                                            </div>
                                        </div>
                                        <div className="flex gap-4 items-center">
                                            <button
                                                onClick={() => setShowPublicityAnalytics(true)}
                                                className="px-2 py-1 bg-emerald-500/10 hover:bg-emerald-500/20 rounded border border-emerald-500/20 text-[9px] font-black uppercase text-emerald-400 transition-all flex items-center gap-1.5"
                                            >
                                                <TrendingUp size={10} /> Full Analytics
                                            </button>
                                            <div className="flex bg-black/40 p-0.5 rounded-lg border border-white/5">
                                                {(['Todos', 'Barco', 'Cueva'] as const).map(g => (
                                                    <button
                                                        key={g}
                                                        onClick={() => setPubGridGroup(g)}
                                                        className={`px-2 py-1 rounded text-[8px] font-black uppercase transition-all ${pubGridGroup === g ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/20' : 'text-slate-500 hover:text-emerald-400'}`}
                                                    >
                                                        {g === 'Todos' ? 'Total' : g}
                                                    </button>
                                                ))}
                                            </div>
                                            <div className="text-right">
                                                <div className="text-xs font-mono font-bold text-emerald-400">
                                                    Mes: {formatCurrency(Object.keys(publicityActive).filter(k => k.startsWith(`${pubYear}-${(pubMonth + 1).toString().padStart(2, '0')}`)).reduce((acc, k) => acc + (publicityActive[k]?.[pubGridGroup === 'Todos' ? 'Total' : pubGridGroup] || 0), 0) || 0)}
                                                </div>
                                                <div className="text-[9px] text-slate-500 font-bold uppercase">Inversión Lograda</div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-7 sm:grid-cols-10 md:grid-cols-7 lg:grid-cols-10 gap-1.5">
                                        {Array.from({ length: new Date(pubYear, pubMonth + 1, 0).getDate() }, (_, i) => {
                                            const day = i + 1;
                                            const dateKey = `${pubYear}-${(pubMonth + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
                                            const dayData = publicityActive[dateKey];
                                            const hasWork = !!dayData?.[pubGridGroup === 'Todos' ? 'Total' : pubGridGroup];
                                            return (
                                                <button
                                                    key={day}
                                                    onClick={() => setShowPublicityAnalytics(true)}
                                                    className={`aspect-square rounded-lg border flex flex-col items-center justify-center gap-0.5 transition-all ${hasWork ? 'bg-emerald-600 border-emerald-400 text-white shadow-lg shadow-emerald-500/20' : 'bg-slate-950/50 border-slate-800 text-slate-500 hover:border-slate-600'}`}
                                                    title={hasWork ? `Total: ${formatCurrency(dayData.Total)}\nBarco: ${formatCurrency(dayData.Barco || 0)}\nCueva: ${formatCurrency(dayData.Cueva || 0)}` : 'Sin gasto'}
                                                >
                                                    <span className="text-[8px] font-bold opacity-60">D{day}</span>
                                                    {hasWork ? (
                                                        <div className="flex flex-col items-center gap-1">
                                                            <div className="flex gap-1">
                                                                {(pubGridGroup === 'Todos' || pubGridGroup === 'Barco') && dayData.Barco > 0 && <div className="w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_5px_white]"></div>}
                                                                {(pubGridGroup === 'Todos' || pubGridGroup === 'Cueva') && dayData.Cueva > 0 && <div className="w-1.5 h-1.5 rounded-full bg-orange-400 shadow-[0_0_5px_rgba(251,146,60,0.8)]"></div>}
                                                            </div>
                                                            <span className="text-[7px] font-mono leading-none font-bold">
                                                                {formatCurrency(dayData[pubGridGroup === 'Todos' ? 'Total' : pubGridGroup]).replace('$', '').trim()}
                                                            </span>
                                                        </div>
                                                    ) : <span className="text-xs font-bold font-mono text-white/5 italic">·</span>}
                                                </button>
                                            );
                                        })}
                                    </div>
                                </div>

                                {/* MINI CHART PUBLICIDAD (NEON GREEN) */}
                                <div className="bg-black/60 rounded-xl p-4 border border-emerald-500/10 h-40 shadow-inner">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <AreaChart data={Array.from({ length: new Date(pubYear, pubMonth + 1, 0).getDate() }, (_, i) => {
                                            const day = i + 1;
                                            const dateKey = `${pubYear}-${(pubMonth + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
                                            return { dia: day, activo: publicityActive[dateKey]?.[pubGridGroup === 'Todos' ? 'Total' : pubGridGroup] || 0 };
                                        })}>
                                            <defs>
                                                <linearGradient id="colorPubNeon" x1="0" y1="0" x2="0" y2="1">
                                                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.6} />
                                                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                                                </linearGradient>
                                            </defs>
                                            <XAxis dataKey="dia" hide />
                                            <YAxis hide />
                                            <Tooltip
                                                contentStyle={{ backgroundColor: '#052c16', border: '1px solid #16a34a', borderRadius: '12px', fontSize: '10px', boxShadow: '0 0 15px rgba(34,197,94,0.3)' }}
                                                itemStyle={{ color: '#4ade80' }}
                                                formatter={(value: any) => [formatCurrency(Number(value) || 0), 'Inversión']}
                                            />
                                            <Area type="monotone" dataKey="activo" stroke="#4ade80" fill="url(#colorPubNeon)" strokeWidth={3} animationDuration={1500} />
                                        </AreaChart>
                                    </ResponsiveContainer>
                                    <div className="text-center mt-2 text-[9px] text-emerald-500/50 font-bold uppercase tracking-[0.2em]">Live Pulse Investment</div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            {/* --- MODAL (GLASS) --- */}
            {
                activeModal && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
                        <div className="bg-slate-900 border border-slate-700/50 rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl scale-100 animate-in zoom-in-95 duration-200 ring-1 ring-white/10">
                            <div className="p-5 border-b border-slate-700/50 flex justify-between items-center bg-slate-950/50">
                                <h3 className="text-lg font-bold text-white tracking-tight">
                                    {activeModal === 'operative' && (editingItem ? 'Editar Día' : 'Nuevo Día')}
                                    {activeModal === 'shipment' && (editingItem ? 'Editar Envío' : 'Registrar Envío')}
                                    {activeModal === 'bank' && (editingItem ? 'Editar Banco' : 'Nuevo Banco')}
                                    {activeModal === 'employee' && (editingItem ? 'Editar Staff' : 'Nuevo Staff')}
                                    {activeModal === 'player' && 'Actualizar Saldo'}
                                    {activeModal === 'felipe_advance' && 'Nuevo Adelanto Felipe'}
                                </h3>
                                <button onClick={() => setActiveModal(null)} className="text-slate-500 hover:text-white transition-colors bg-slate-800 p-1 rounded-full"><X size={16} /></button>
                            </div>

                            <form onSubmit={(e) => {
                                if (activeModal === 'operative') handleSaveOp(e);
                                else if (activeModal === 'shipment') handleSaveShip(e);
                                else if (activeModal === 'bank') handleSaveBank(e);
                                else if (activeModal === 'player') handleSavePlayer(e);
                                else if (activeModal === 'felipe_advance') handleSaveFelipeAdvance(e);
                                else handleSaveEmployee(e);
                            }} className="p-5 space-y-4">

                                {activeModal === 'operative' && (
                                    <>
                                        <input autoFocus type="text" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-yellow-500 outline-none transition-all focus:border-yellow-500" placeholder="Día (Ej. 12)" value={opForm.dia} onChange={e => setOpForm({ ...opForm, dia: e.target.value })} />
                                        <div className="grid grid-cols-2 gap-3">
                                            <div className="space-y-1">
                                                <label className="text-[10px] text-yellow-500 font-bold uppercase ml-1">Monto Barco</label>
                                                <input type="number" min="0" step="any" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-yellow-500 outline-none transition-all focus:border-yellow-500" placeholder="0" value={opForm.barco} onChange={e => setOpForm({ ...opForm, barco: e.target.value })} />
                                            </div>
                                            <div className="space-y-1">
                                                <label className="text-[10px] text-pink-400 font-bold uppercase ml-1">Monto Cueva</label>
                                                <input type="number" min="0" step="any" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-pink-500 outline-none transition-all focus:border-pink-500" placeholder="0" value={opForm.cueva} onChange={e => setOpForm({ ...opForm, cueva: e.target.value })} />
                                            </div>
                                            <div className="space-y-1">
                                                <label className="text-[10px] text-yellow-500/60 font-bold uppercase ml-1">Mesas Barco</label>
                                                <input type="number" min="0" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-yellow-500/50 outline-none" placeholder="0" value={opForm.mesasBarco} onChange={e => setOpForm({ ...opForm, mesasBarco: e.target.value })} />
                                            </div>
                                            <div className="space-y-1">
                                                <label className="text-[10px] text-pink-400/60 font-bold uppercase ml-1">Mesas Cueva</label>
                                                <input type="number" min="0" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-pink-500/50 outline-none" placeholder="0" value={opForm.mesasCueva} onChange={e => setOpForm({ ...opForm, mesasCueva: e.target.value })} />
                                            </div>
                                        </div>
                                    </>
                                )}

                                {activeModal === 'shipment' && (
                                    <>
                                        <input autoFocus type="text" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-purple-500 outline-none transition-all focus:border-purple-500" placeholder="Fecha (Ej. 12/01)" value={shipForm.fecha} onChange={e => setShipForm({ ...shipForm, fecha: e.target.value })} />
                                        <input type="number" step="any" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-purple-500 outline-none transition-all focus:border-purple-500" placeholder="Monto" value={shipForm.monto} onChange={e => setShipForm({ ...shipForm, monto: e.target.value })} />
                                        <input type="text" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-purple-500 outline-none transition-all focus:border-purple-500" placeholder="Nota (Opcional)" value={shipForm.nota} onChange={e => setShipForm({ ...shipForm, nota: e.target.value })} />
                                        <div className="relative">
                                            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-purple-500/50"><Upload size={14} /></div>
                                            <input type="text" className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-4 py-3 text-white focus:ring-1 focus:ring-purple-500 outline-none transition-all focus:border-purple-500" placeholder="Link Comprobante (Drive)" value={shipForm.comprobante} onChange={e => setShipForm({ ...shipForm, comprobante: e.target.value })} />
                                        </div>
                                    </>
                                )}

                                {activeModal === 'bank' && (
                                    <>
                                        <input autoFocus type="text" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-emerald-500 outline-none transition-all focus:border-emerald-500" placeholder="Nombre Banco" value={bankForm.nombre} onChange={e => setBankForm({ ...bankForm, nombre: e.target.value })} />
                                        <input type="number" step="any" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-emerald-500 outline-none transition-all focus:border-emerald-500" placeholder="Monto" value={bankForm.monto} onChange={e => setBankForm({ ...bankForm, monto: e.target.value })} />
                                    </>
                                )}

                                {activeModal === 'player' && (
                                    <>
                                        <div className="text-center mb-2">
                                            <span className="text-slate-400 text-xs uppercase tracking-widest">Saldo Actual</span>
                                            <div className="text-xl font-bold text-white mt-1">{editingItem?.nombre}</div>
                                        </div>
                                        <input autoFocus type="number" step="any" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-pink-500 outline-none transition-transform focus:scale-105 text-center font-mono text-lg font-bold" value={playerForm.saldo} onChange={e => setPlayerForm({ ...playerForm, saldo: e.target.value })} />
                                    </>
                                )}

                                {activeModal === 'employee' && (
                                    <>
                                        <input autoFocus type="text" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-indigo-500 outline-none" placeholder="Nombre completo" value={employeeForm.name} onChange={e => setEmployeeForm({ ...employeeForm, name: e.target.value })} />
                                        <select className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-indigo-500 outline-none" value={employeeForm.shift} onChange={e => setEmployeeForm({ ...employeeForm, shift: e.target.value })}>
                                            <option value="Mañana">Turno Mañana</option>
                                            <option value="Noche">Turno Noche</option>
                                            <option value="Franquero">Franquero</option>
                                        </select>
                                        <select className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-indigo-500 outline-none" value={employeeForm.status} onChange={e => setEmployeeForm({ ...employeeForm, status: e.target.value })}>
                                            <option value="Activo">Activo</option>
                                            <option value="Ausente">Ausente</option>
                                            <option value="Suplente">Suplente</option>
                                            <option value="Renunció">Renunció</option>
                                        </select>
                                        <select className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-indigo-500 outline-none" value={employeeForm.group} onChange={e => setEmployeeForm({ ...employeeForm, group: e.target.value })}>
                                            <option value="Barco">Bando: Barco</option>
                                            <option value="Cueva">Bando: Cueva</option>
                                        </select>
                                    </>
                                )}

                                {activeModal === 'felipe_advance' && (
                                    <>
                                        <input autoFocus type="text" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-red-500 outline-none" placeholder="Motivo o Razón" value={felipeAdvanceForm.motivo} onChange={e => setFelipeAdvanceForm({ ...felipeAdvanceForm, motivo: e.target.value })} />
                                        <input type="number" step="any" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-red-500 outline-none" placeholder="Monto a descontar ($)" value={felipeAdvanceForm.monto} onChange={e => setFelipeAdvanceForm({ ...felipeAdvanceForm, monto: e.target.value })} />
                                    </>
                                )}

                                <button className="w-full bg-gradient-to-r from-slate-800 to-slate-900 hover:from-slate-700 hover:to-slate-800 text-white font-bold py-3 rounded-xl transition-all border border-slate-700 shadow-lg mt-2 tracking-wide uppercase text-sm">Guardar Cambios</button>
                            </form>
                        </div>
                    </div>
                )
            }

            {/* --- MASTER MODAL (OPERATIONS) --- */}
            {
                showMasterModal && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200">
                        <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden shadow-2xl flex flex-col">
                            <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-950/50">
                                <div>
                                    <h3 className="text-xl font-bold text-white flex items-center gap-2">
                                        <Activity className="text-emerald-500" /> Maestro de Operaciones
                                    </h3>
                                    <p className="text-slate-400 text-xs mt-1">Visión global de todos los movimientos operativos (App Móvil)</p>
                                </div>
                                <button onClick={() => setShowMasterModal(false)} className="text-slate-500 hover:text-white bg-slate-800 p-2 rounded-full"><X size={20} /></button>
                            </div>

                            <div className="flex-1 overflow-auto p-6 space-y-6">
                                {/* SECCION CARGA COMPROBANTES */}
                                {role === 'admin' && (
                                    <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
                                        <h4 className="text-indigo-400 font-bold uppercase text-xs tracking-widest mb-4 flex items-center gap-2">
                                            <Upload size={14} /> Subir Pago / Comprobante
                                        </h4>
                                        <div className="flex gap-4 items-end">
                                            <div className="flex-1">
                                                <label className="text-xs text-slate-500 mb-1 block">Usuario Destino</label>
                                                <select className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white text-sm outline-none focus:border-indigo-500" onChange={e => setSelectedUserForReceipt(e.target.value)} value={selectedUserForReceipt || ''}>
                                                    <option value="">Seleccionar perfil de usuario...</option>
                                                    {employees.map((emp: any) => (
                                                        <option key={emp.id} value={emp.email || ''}>
                                                            {emp.name} ({emp.group} - {emp.shift})
                                                        </option>
                                                    ))}
                                                </select>
                                            </div>
                                            <div className="flex-[2]">
                                                <label className="text-xs text-slate-500 mb-1 block">Comprobante (Imagen/PDF)</label>
                                                <div className="flex gap-2">
                                                    <input
                                                        type="file"
                                                        accept="image/*,application/pdf"
                                                        onChange={async (e) => {
                                                            const file = e.target.files?.[0];
                                                            if (!file) return;

                                                            // Upload Logic Inline
                                                            setUploadUrl(''); // Clear previous
                                                            const fileName = `${Date.now()}_${file.name.replace(/\s+/g, '-')}`;
                                                            const { error } = await supabase.storage.from('comprobantes').upload(fileName, file);

                                                            if (error) {
                                                                alert(`Error subiendo: ${error.message} (Verifica que exista el bucket 'comprobantes' publico en Supabase)`);
                                                            } else {
                                                                const { data } = supabase.storage.from('comprobantes').getPublicUrl(fileName);
                                                                setUploadUrl(data.publicUrl);
                                                            }
                                                        }}
                                                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-slate-300 text-xs file:mr-2 file:py-1 file:px-2 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-indigo-500/10 file:text-indigo-400 hover:file:bg-indigo-500/20"
                                                    />
                                                </div>
                                                {uploadUrl && <span className="text-[10px] text-emerald-400 mt-1 block">✅ Archivo listo para asignar</span>}
                                            </div>
                                            <button onClick={handleUploadReceipt} disabled={!uploadUrl || !selectedUserForReceipt} className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg text-sm font-bold shadow-lg transition-all">
                                                ASIGNAR
                                            </button>
                                        </div>
                                    </div>
                                )}

                                {/* TABLA DE REGISTROS (CON EDICIÓN) */}
                                <div>
                                    <h4 className="text-emerald-400 font-bold uppercase text-xs tracking-widest mb-4">Últimos Registros (Tiempo Real)</h4>

                                    {editingLog ? (
                                        <div className="bg-slate-800 p-6 rounded-xl border border-yellow-500/50 shadow-xl animate-in fade-in zoom-in-95 duration-200">
                                            <h3 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
                                                <Edit2 className="text-yellow-400" size={20} /> Editar Registro <span className="text-slate-500 text-sm">ID: {editingLog.id.toString().slice(0, 8)}...</span>
                                            </h3>
                                            <form onSubmit={handleUpdateMasterLog} className="space-y-4">
                                                <div className="grid grid-cols-2 gap-4">
                                                    <div>
                                                        <label className="text-xs text-slate-500 block mb-1">Fecha Operación</label>
                                                        <input type="date" required className="bg-slate-950 text-white rounded-lg p-2 w-full border border-slate-700 focus:border-yellow-500 outline-none"
                                                            value={editingLog.fecha_operacion}
                                                            onChange={e => setEditingLog({ ...editingLog, fecha_operacion: e.target.value })} />
                                                    </div>
                                                    <div>
                                                        <label className="text-xs text-slate-500 block mb-1">Monto Apuesta</label>
                                                        <input type="number" step="any" required className="bg-slate-950 text-white rounded-lg p-2 w-full border border-slate-700 focus:border-yellow-500 outline-none"
                                                            value={editingLog.monto_apuesta}
                                                            onChange={e => setEditingLog({ ...editingLog, monto_apuesta: e.target.value })} />
                                                    </div>
                                                    <div>
                                                        <label className="text-xs text-slate-500 block mb-1">Bando</label>
                                                        <select className="bg-slate-950 text-white rounded-lg p-2 w-full border border-slate-700 focus:border-yellow-500 outline-none"
                                                            value={editingLog.bando}
                                                            onChange={e => setEditingLog({ ...editingLog, bando: e.target.value })}>
                                                            <option value="Barco">Barco</option>
                                                            <option value="Cueva">Cueva</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div className="flex justify-end gap-2 mt-4 pt-4 border-t border-slate-700">
                                                    <button type="button" onClick={() => setEditingLog(null)} className="px-4 py-2 text-slate-400 hover:text-white text-sm">Cancelar</button>
                                                    <button type="submit" className="px-6 py-2 bg-yellow-600 hover:bg-yellow-500 text-slate-950 rounded-lg text-sm font-bold shadow-lg shadow-yellow-500/20">Guardar Cambios</button>
                                                </div>
                                            </form>
                                        </div>
                                    ) : (
                                        <div className="overflow-x-auto rounded-xl border border-slate-800">
                                            <table className="w-full text-left text-sm text-slate-400">
                                                <thead className="bg-slate-950 text-xs uppercase font-bold text-slate-500">
                                                    <tr>
                                                        <th className="p-3">Hora</th>
                                                        <th className="p-3">Usuario</th>
                                                        <th className="p-3">Bando</th>
                                                        <th className="p-3">Mesa</th>
                                                        <th className="p-3 text-right text-indigo-400">Apuesta</th>
                                                        <th className="p-3 text-right text-emerald-400">Ganancia (8%)</th>
                                                        <th className="p-3 text-center">Acciones</th>
                                                    </tr>
                                                </thead>
                                                <tbody className="divide-y divide-slate-800 bg-slate-900/40">
                                                    {masterLogs.filter((log: any) => dashboardGroup === 'Todos' || log.bando === dashboardGroup).map((log: any) => (
                                                        <tr key={log.id} className="hover:bg-slate-800/50 transition-colors group">
                                                            <td className="p-3 font-mono text-xs">{log.fecha_operacion} <span className="text-slate-600">{log.hora_registro}</span></td>
                                                            <td className="p-3 text-white font-bold text-xs">{log.user_email.split('@')[0]}</td>
                                                            <td className="p-3"><span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold border ${log.bando === 'Barco' ? 'border-yellow-500/30 text-yellow-400 bg-yellow-500/10' : 'border-pink-500/30 text-pink-400 bg-pink-500/10'}`}>{log.bando}</span></td>
                                                            <td className="p-3 text-white text-xs opacity-50">{log.mesa}</td>
                                                            <td className="p-3 text-right font-mono text-white">${log.monto_apuesta}</td>
                                                            <td className="p-3 text-right font-mono text-emerald-300 font-bold">+${log.ganancia_calculada.toFixed(2)}</td>
                                                            <td className="p-3 flex justify-center gap-2">
                                                                {role === 'admin' && (
                                                                    <>
                                                                        <button onClick={() => setEditingLog(log)} className="p-1.5 hover:bg-yellow-500/20 rounded text-slate-500 hover:text-yellow-400 transition-colors"><Edit2 size={14} /></button>
                                                                        <button onClick={() => handleDeleteMasterLog(log.id)} className="p-1.5 hover:bg-red-500/20 rounded text-slate-500 hover:text-red-400 transition-colors"><Trash2 size={14} /></button>
                                                                    </>
                                                                )}
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                )
            }


            {/* --- CALCULADORA FLOTANTE --- */}
            {
                showCalc && (
                    <div className="fixed bottom-10 right-10 z-[60] w-64 bg-slate-900/90 backdrop-blur-2xl border border-slate-700/50 rounded-3xl shadow-2xl p-4 animate-in slide-in-from-bottom-5 duration-300 ring-1 ring-white/10 no-print">
                        <div className="flex justify-between items-center mb-4 px-1">
                            <div className="flex items-center gap-2">
                                <div className="p-1.5 bg-yellow-500/20 rounded-lg text-yellow-500"><CalcIcon size={14} /></div>
                                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Calculadora</span>
                            </div>
                            <button onClick={() => setShowCalc(false)} className="text-slate-500 hover:text-white transition-colors bg-slate-800 p-1 rounded-full"><X size={12} /></button>
                        </div>

                        <div className="bg-black/40 border border-slate-800 rounded-2xl p-4 mb-4">
                            <div className="text-[10px] text-slate-600 font-mono text-right h-4 overflow-hidden mb-1">
                                {prevValue} {pendingOp}
                            </div>
                            <div className="text-2xl font-mono font-bold text-white text-right truncate">
                                {calcValue}
                            </div>
                        </div>

                        <div className="grid grid-cols-4 gap-2">
                            {['C', '/', '*', '-'].map(btn => (
                                <button key={btn} onClick={() => handleCalcAction(btn)} className={`p-3 rounded-xl font-bold flex items-center justify-center transition-all ${btn === 'C' ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30' : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'}`}>
                                    {btn}
                                </button>
                            ))}
                            {[7, 8, 9, '+'].map(btn => (
                                <button key={btn} onClick={() => handleCalcAction(btn.toString())} className={`p-3 rounded-xl font-bold flex items-center justify-center transition-all ${btn === '+' ? 'row-span-2 bg-indigo-600/20 text-indigo-400 hover:bg-indigo-600/30' : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'}`}>
                                    {btn}
                                </button>
                            ))}
                            {[4, 5, 6].map(btn => (
                                <button key={btn} onClick={() => handleCalcAction(btn.toString())} className="p-3 bg-slate-800 text-slate-300 rounded-xl font-bold flex items-center justify-center hover:bg-slate-700 hover:text-white transition-all">
                                    {btn}
                                </button>
                            ))}
                            {[1, 2, 3, '='].map(btn => (
                                <button key={btn} onClick={() => handleCalcAction(btn.toString())} className={`p-3 rounded-xl font-bold flex items-center justify-center transition-all ${btn === '=' ? 'row-span-2 bg-yellow-500 text-slate-950 hover:bg-yellow-400 shadow-lg shadow-yellow-500/20' : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'}`}>
                                    {btn}
                                </button>
                            ))}
                            <button onClick={() => handleCalcAction('0')} className="col-span-2 p-3 bg-slate-800 text-slate-300 rounded-xl font-bold flex items-center justify-center hover:bg-slate-700 hover:text-white transition-all">0</button>
                            <button onClick={() => handleCalcAction('.')} className="p-3 bg-slate-800 text-slate-300 rounded-xl font-bold flex items-center justify-center hover:bg-slate-700 hover:text-white transition-all">.</button>
                        </div>
                    </div>
                )
            }

            {/* --- BINANCE FLOATING CONVERTER --- */}
            {
                showBinanceCalc && (
                    <div className="fixed bottom-10 right-10 z-[60] w-80 bg-slate-900/95 backdrop-blur-3xl border border-yellow-500/30 rounded-[2.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.5),0_0_30px_rgba(234,179,8,0.1)] p-6 animate-in zoom-in-95 slide-in-from-bottom-10 duration-500 ring-1 ring-white/10 no-print">
                        <div className="flex justify-between items-start mb-6">
                            <div className="flex flex-col gap-1">
                                <h3 className="text-[10px] font-black uppercase text-yellow-500 tracking-[0.3em] flex items-center gap-2">
                                    <div className="p-1.5 bg-yellow-500/20 rounded-xl text-yellow-500"><CircleDollarSign size={16} /></div>
                                    Binance Live
                                </h3>
                                <div className="flex items-center gap-2 mt-1">
                                    <span className="text-2xl font-mono font-black text-white">{formatCurrency(usdtRate)}</span>
                                    <span className="text-[8px] bg-emerald-500 text-black px-1.5 py-0.5 rounded-full font-black tracking-widest animate-pulse">LIVE</span>
                                </div>
                            </div>
                            <button onClick={() => setShowBinanceCalc(false)} className="text-slate-500 hover:text-white transition-all bg-slate-800 p-2 rounded-full hover:rotate-90 duration-300"><X size={14} /></button>
                        </div>

                        <div className="space-y-4">
                            <div className="bg-black/40 border border-white/5 rounded-3xl p-5 space-y-4 shadow-inner">
                                <div className="space-y-1.5">
                                    <label className="text-[9px] text-slate-500 font-black uppercase tracking-widest ml-1">Pesos (ARS)</label>
                                    <div className="relative">
                                        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500 font-black">$</div>
                                        <input
                                            type="number"
                                            className="w-full bg-slate-900/50 border border-slate-700/50 rounded-2xl pl-10 pr-4 py-3 text-white font-mono font-bold focus:ring-2 focus:ring-yellow-500/20 outline-none transition-all"
                                            placeholder="ARS"
                                            value={binanceARS}
                                            onChange={e => {
                                                const val = e.target.value;
                                                setBinanceARS(val);
                                                const num = parseFloat(val);
                                                if (!isNaN(num) && usdtRate > 0) setBinanceUSDT((num / usdtRate).toFixed(2));
                                                else setBinanceUSDT('');
                                            }}
                                        />
                                    </div>
                                </div>

                                <div className="flex justify-center py-1">
                                    <RefreshCw size={12} className="text-slate-700" />
                                </div>

                                <div className="space-y-1.5">
                                    <label className="text-[9px] text-slate-500 font-black uppercase tracking-widest ml-1">Cripto (USDT)</label>
                                    <div className="relative">
                                        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500 font-black">₮</div>
                                        <input
                                            type="number"
                                            className="w-full bg-slate-900/50 border border-slate-700/50 rounded-2xl pl-10 pr-4 py-3 text-white font-mono font-bold focus:ring-2 focus:ring-yellow-500/20 outline-none transition-all"
                                            placeholder="USDT"
                                            value={binanceUSDT}
                                            onChange={e => {
                                                const val = e.target.value;
                                                setBinanceUSDT(val);
                                                const num = parseFloat(val);
                                                if (!isNaN(num) && usdtRate > 0) setBinanceARS((num * usdtRate).toFixed(0));
                                                else setBinanceARS('');
                                            }}
                                        />
                                    </div>
                                </div>
                            </div>

                            <button
                                onClick={fetchLivePrice}
                                disabled={isFetchingPrice}
                                className="w-full py-3 bg-yellow-500 text-black rounded-2xl font-black text-[10px] tracking-[0.2em] uppercase hover:bg-yellow-400 transition-all flex items-center justify-center gap-2 shadow-lg shadow-yellow-500/20 disabled:opacity-50"
                            >
                                <RefreshCw size={14} className={isFetchingPrice ? 'animate-spin' : ''} />
                                Actualizar Tasa
                            </button>
                        </div>
                    </div>
                )
            }

            {/* --- MODAL DETALLE DE TURNO --- */}
            {activeModal === 'shiftDetail' && activeShiftDay && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300">
                    <div className="bg-slate-900/90 border border-indigo-500/30 w-full max-w-sm rounded-[2rem] p-8 shadow-2xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-4 opacity-5 text-indigo-500"><Activity size={80} /></div>

                        <div className="flex justify-between items-center mb-6">
                            <div>
                                <h3 className="text-white font-black text-xl tracking-tight">Registro de Asistencia</h3>
                                <p className="text-indigo-400 text-[10px] font-bold uppercase tracking-widest mt-1">Día {activeShiftDay.day} • {employees.find((e: any) => e.id === activeShiftDay.empId)?.name}</p>
                            </div>
                            <button onClick={() => setActiveModal(null)} className="p-2 hover:bg-white/10 rounded-full text-slate-400 transition-colors"><X size={20} /></button>
                        </div>

                        <form onSubmit={(e) => {
                            e.preventDefault();
                            const newStatus = parseFloat(shiftDetailForm.horas) > 0 ? 'Presente' : 'Falta';
                            handleShiftChange(activeShiftDay.empId, activeShiftDay.day, { ...shiftDetailForm, estatus: newStatus });
                            setActiveModal(null);
                        }} className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <label className="text-[10px] text-slate-500 font-bold uppercase ml-1">Entrada</label>
                                    <input
                                        type="text"
                                        placeholder="HH:MM"
                                        className="w-full bg-slate-950/50 border border-slate-700/50 rounded-xl py-3 px-4 text-white font-mono focus:border-indigo-500 transition-all outline-none"
                                        value={shiftDetailForm.entrada}
                                        onChange={(e) => setShiftDetailForm({ ...shiftDetailForm, entrada: e.target.value })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[10px] text-slate-500 font-bold uppercase ml-1">Salida</label>
                                    <input
                                        type="text"
                                        placeholder="HH:MM"
                                        className="w-full bg-slate-950/50 border border-slate-700/50 rounded-xl py-3 px-4 text-white font-mono focus:border-indigo-500 transition-all outline-none"
                                        value={shiftDetailForm.salida}
                                        onChange={(e) => setShiftDetailForm({ ...shiftDetailForm, salida: e.target.value })}
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <label className="text-[10px] text-slate-500 font-bold uppercase ml-1">Total Horas</label>
                                <input
                                    type="text"
                                    placeholder="0.0"
                                    required
                                    className="w-full bg-slate-950/50 border border-emerald-500/30 rounded-xl py-4 px-4 text-emerald-400 font-mono text-2xl font-black focus:border-emerald-500 transition-all outline-none text-center"
                                    value={shiftDetailForm.horas}
                                    onChange={(e) => setShiftDetailForm({ ...shiftDetailForm, horas: e.target.value })}
                                />
                            </div>

                            <div className="pt-4">
                                <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black py-4 rounded-xl shadow-[0_0_20px_rgba(79,70,229,0.3)] transition-all flex items-center justify-center gap-2">
                                    <Save size={18} /> GUARDAR REGISTRO
                                </button>
                            </div>
                            <p className="text-[8px] text-slate-500 italic text-center uppercase tracking-tighter">Automatic status: {parseFloat(shiftDetailForm.horas) > 0 ? 'Presente' : 'Falta'}</p>
                        </form>
                    </div>
                </div>
            )}
            {/* --- NÓMINA PRINCIPAL FULL MODULE --- */}
            {showNominaPage && (
                <NominaModule
                    user={{ email: userEmail, role, name: role === 'admin' ? 'Administrador' : userEmail.split('@')[0] }}
                    employees={employees}
                    shiftsMatrix={shiftsMatrix}
                    onBack={() => setShowNominaPage(false)}
                    onSave={(newMatrix) => {
                        setShiftsMatrix(newMatrix);
                        // Trigger save to cloud indirectly 
                        setTimeout(() => saveToCloud(), 100);
                    }}
                    syncWithDB={syncEmployeesWithDB}
                />
            )}
        </div>
    );
};

export default Dashboard;
