import React, { useState, useEffect } from 'react';
import {
    Users, X, Search, Save, Plus,
    Clock, DollarSign, CheckCircle2,
    RefreshCw, ChevronLeft, Activity, Edit3, Trash2
} from 'lucide-react';

interface NominaProp {
    user: { email: string; role: string; name: string };
    employees: any[];
    shiftsMatrix: any;
    onBack?: () => void;
    onSave?: (updatedMatrix: any) => void;
    syncWithDB?: () => Promise<void>;
}

const SHIFT_VALUE_USD = 9.60;
const HOURS_PER_SHIFT = 9;
const HOURLY_RATE = SHIFT_VALUE_USD / HOURS_PER_SHIFT;

const monthNames = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];

const NominaModule: React.FC<NominaProp> = ({ user, employees, shiftsMatrix, onBack, onSave, syncWithDB }) => {
    const [localMatrix, setLocalMatrix] = useState(shiftsMatrix);
    const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
    const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
    const [fortnight, setFortnight] = useState<1 | 2>(new Date().getDate() <= 15 ? 1 : 2);
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedStatus, setSelectedStatus] = useState<'Todos' | 'Presente' | 'Falta' | 'Franco'>('Todos');

    // UI States
    const [activeModal, setActiveModal] = useState<'detail' | null>(null);
    const [activeEntry, setActiveEntry] = useState<{ empId: string; day: number; isNew?: boolean } | null>(null);
    const [detailForm, setDetailForm] = useState({ entrada: '', salida: '', horas: '0', estatus: 'Falta', notas: '' });

    useEffect(() => {
        setLocalMatrix(shiftsMatrix);
    }, [shiftsMatrix]);

    const isAdmin = user.role === 'admin';

    // Generar días de la quincena
    const getDays = () => {
        const lastDay = new Date(selectedYear, selectedMonth + 1, 0).getDate();
        const start = fortnight === 1 ? 1 : 16;
        const end = fortnight === 1 ? 15 : lastDay;
        const days = [];
        for (let i = start; i <= end; i++) days.push(i);
        return days;
    };

    const days = getDays();

    // Aplanar datos para el listado tipo hoja
    const generateFlatData = () => {
        const flat: any[] = [];
        employees.forEach(emp => {
            if (searchQuery && !emp.name.toLowerCase().includes(searchQuery.toLowerCase())) return;

            days.forEach(day => {
                const entry = localMatrix[emp.id]?.[day] || {};
                const val = typeof entry === 'object' ? entry : { horas: entry, estatus: parseFloat(entry) > 0 ? 'Presente' : 'Falta' };

                const horas = parseFloat(val.horas) || 0;
                const totalPay = horas * HOURLY_RATE;
                const status = val.estatus || (horas > 0 ? 'Presente' : 'Falta');

                if (selectedStatus !== 'Todos' && status !== selectedStatus) return;

                const name = emp.name.toLowerCase();

                // LOGICA DE VISUALIZACION: Enero Control (Defaults)
                // SOLO aplicamos el filtro si NO hay un registro manual explicito.
                // Si el usuario agrega un dia manualmente (localMatrix tiene datos), lo mostramos SIEMPRE.
                const hasManualEntry = localMatrix[emp.id]?.[day];

                if (selectedMonth === 0 && !hasManualEntry) {
                    if (day === 1) {
                        // Dia 01: Default oculta a Willy
                        if (name.includes('willy')) return;
                    } else {
                        // Dia 02+: Default oculta a Dasos
                        if (name.includes('dasos')) return;
                    }
                }

                // OVERRIDE: Francis y Clemente son "Franquero" visualmente
                let finalGroup = emp.group;
                if (name.includes('francis') || name.includes('clemente')) {
                    finalGroup = 'Franquero';
                }

                flat.push({
                    empId: emp.id,
                    name: emp.name,
                    group: finalGroup,
                    day,
                    date: `${day.toString().padStart(2, '0')}/${(selectedMonth + 1).toString().padStart(2, '0')}/${selectedYear}`,
                    entrada: val.entrada || '0',
                    salida: val.salida || '0',
                    horas: horas.toFixed(2),
                    rate: HOURLY_RATE.toFixed(2),
                    pay: totalPay.toFixed(2),
                    status,
                    notas: val.notas || ''
                });
            });
        });

        // Sort by Day first (Chronological), then by Name
        return flat.sort((a, b) => a.day - b.day || a.name.localeCompare(b.name));
    };

    const flatData = generateFlatData();

    const handleNewEntry = () => {
        if (!isAdmin) return;
        setDetailForm({ entrada: '', salida: '', horas: '0', estatus: 'Falta', notas: '' });
        // Default to first employee and first day of current fortnight view
        setActiveEntry({ empId: employees[0]?.id, day: days[0], isNew: true });
        setActiveModal('detail');
    };

    const handleOpenDetail = (empId: string, day: number) => {
        if (!isAdmin) return;
        const entry = localMatrix[empId]?.[day] || {};
        const val = typeof entry === 'object' ? entry : { entrada: '', salida: '', horas: entry, estatus: parseFloat(entry) > 0 ? 'Presente' : 'Falta', notas: '' };

        setDetailForm({
            entrada: val.entrada || '',
            salida: val.salida || '',
            horas: val.horas || '0',
            estatus: val.estatus || (parseFloat(val.horas) > 0 ? 'Presente' : 'Falta'),
            notas: val.notas || ''
        });
        setActiveEntry({ empId, day });
        setActiveModal('detail');
    };

    const handleSaveDetail = () => {
        if (!activeEntry) return;
        const updated = { ...localMatrix };
        if (!updated[activeEntry.empId]) updated[activeEntry.empId] = {};

        // Auto-estatus
        let finalStatus = detailForm.estatus;
        if (parseFloat(detailForm.horas) > 0 && finalStatus === 'Falta') finalStatus = 'Presente';
        if (parseFloat(detailForm.horas) === 0 && finalStatus === 'Presente') finalStatus = 'Falta';

        updated[activeEntry.empId][activeEntry.day] = { ...detailForm, estatus: finalStatus };
        setLocalMatrix(updated);
        setActiveModal(null);
    };

    const handleDeleteEntry = (e: React.MouseEvent, empId: string, day: number) => {
        e.stopPropagation();
        if (!confirm('¿Estás seguro de borrar este registro?')) return;
        const updated = { ...localMatrix };
        if (updated[empId]) {
            delete updated[empId][day];
            setLocalMatrix({ ...updated });
        }
    };

    const handleGlobalSave = () => {
        if (onSave) onSave(localMatrix);
        alert("Nómina guardada y sincronizada con éxito.");
    };

    // Totales
    const totalPaid = flatData.reduce((acc, curr) => acc + parseFloat(curr.pay), 0);
    const totalHours = flatData.reduce((acc, curr) => acc + parseFloat(curr.horas), 0);
    const presentCount = flatData.filter(d => d.status === 'Presente').length;

    return (
        <div className="fixed inset-0 z-[120] bg-[#020617] text-slate-200 flex flex-col animate-in fade-in duration-300 overflow-hidden font-sans">
            {/* Background Decor */}
            <div className="absolute inset-0 pointer-events-none opacity-20">
                <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-indigo-600/20 rounded-full blur-[120px]"></div>
                <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-emerald-600/10 rounded-full blur-[120px]"></div>
            </div>

            {/* Header Toolbar */}
            <header className="relative z-10 bg-slate-900/80 backdrop-blur-2xl border-b border-indigo-500/20 px-4 md:px-8 py-5 flex flex-col xl:flex-row gap-6 justify-between items-center shadow-2xl">
                <div className="flex flex-col md:flex-row items-center gap-6 w-full xl:w-auto justify-center xl:justify-start">
                    <button onClick={onBack} className="p-2.5 bg-slate-800 hover:bg-slate-700 rounded-2xl border border-white/5 transition-all group">
                        <ChevronLeft size={20} className="group-hover:-translate-x-0.5 transition-transform" />
                    </button>
                    <div>
                        <h1 className="text-xl md:text-2xl font-black tracking-tighter uppercase italic flex items-center gap-3 justify-center md:justify-start">
                            <div className="p-2 bg-indigo-500/20 rounded-xl text-indigo-400">
                                <Users size={24} />
                            </div>
                            Nómina Principal <span className="text-indigo-500 opacity-50 font-light">V4.0</span>
                        </h1>
                        <p className="text-[8px] md:text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mt-1 ml-1 text-center md:text-left">Administración de Jornadas y Pagos</p>
                    </div>
                </div>

                <div className="flex flex-col md:flex-row items-center gap-4 w-full xl:w-auto justify-center xl:justify-end">
                    <div className="flex bg-slate-950/60 p-1.5 rounded-2xl border border-white/5 shadow-inner gap-2 overflow-x-auto max-w-full">
                        <select
                            value={selectedMonth}
                            onChange={e => setSelectedMonth(Number(e.target.value))}
                            className="bg-transparent text-white text-[10px] font-black uppercase outline-none cursor-pointer px-2 hover:text-indigo-400 transition-colors"
                        >
                            {monthNames.map((m, i) => <option key={i} value={i} className="bg-slate-900">{m}</option>)}
                        </select>
                        <select
                            value={selectedYear}
                            onChange={e => setSelectedYear(Number(e.target.value))}
                            className="bg-transparent text-white text-[10px] font-black uppercase outline-none cursor-pointer px-2 hover:text-indigo-400 transition-colors"
                        >
                            <option value={2025} className="bg-slate-900">2025</option>
                            <option value={2026} className="bg-slate-900">2026</option>
                        </select>
                        <div className="w-px h-4 bg-white/10 my-auto hidden md:block"></div>
                        <button onClick={() => setFortnight(1)} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all whitespace-nowrap ${fortnight === 1 ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'}`}>01-15</button>
                        <button onClick={() => setFortnight(2)} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all whitespace-nowrap ${fortnight === 2 ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'}`}>16-Fin</button>
                    </div>

                    <div className="flex items-center gap-3">
                        <button onClick={handleNewEntry} className="px-5 py-3 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 rounded-2xl border border-indigo-500/20 transition-all font-black text-[10px] uppercase tracking-widest flex items-center gap-2" title="Agregar Registro Manual">
                            <Plus size={16} /> <span className="hidden md:inline">Agregar Día</span>
                        </button>

                        <div className="h-10 w-px bg-white/5 mx-1 hidden md:block"></div>

                        <button onClick={syncWithDB} className="p-3 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 rounded-2xl border border-indigo-500/20 transition-all" title="Sincronizar RRHH">
                            <RefreshCw size={20} />
                        </button>
                        <button onClick={handleGlobalSave} className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-widest rounded-2xl shadow-xl shadow-emerald-600/20 flex items-center gap-2 transition-all active:scale-95 whitespace-nowrap">
                            <Save size={18} /> Guardar
                        </button>
                    </div>
                </div>
            </header>

            {/* Stats Bar */}
            <div className="relative z-10 grid grid-cols-2 lg:grid-cols-4 gap-4 px-4 md:px-8 py-6 bg-slate-900/40 border-b border-white/5">
                {[
                    { label: 'Total Devengado', val: `$${totalPaid.toLocaleString()}`, icon: DollarSign, color: 'emerald' },
                    { label: 'Carga Horaria', val: `${totalHours.toFixed(1)} HRS`, icon: Clock, color: 'blue' },
                    { label: 'Total Agentes', val: employees.length, icon: Users, color: 'indigo' },
                    { label: 'Asistencias', val: presentCount, icon: CheckCircle2, color: 'amber' },
                ].map((stat, i) => (
                    <div key={i} className="bg-black/30 border border-white/5 p-4 rounded-3xl flex items-center gap-4 transition-transform hover:scale-[1.02]">
                        <div className={`p-3 bg-${stat.color}-500/10 rounded-2xl text-${stat.color}-500`}><stat.icon size={20} /></div>
                        <div>
                            <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">{stat.label}</p>
                            <p className="text-xl font-mono font-black text-white">{stat.val}</p>
                        </div>
                    </div>
                ))}
            </div>

            {/* Main Content Area */}
            <main className="flex-1 overflow-hidden flex flex-col p-8 gap-6 relative z-10">
                {/* Filters & Search */}
                <div className="flex flex-col md:flex-row gap-4 items-center bg-slate-900/60 p-5 rounded-3xl border border-white/5 backdrop-blur-xl">
                    <div className="flex-1 w-full relative">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={18} />
                        <input
                            type="text"
                            placeholder="Buscar Agente por nombre..."
                            className="w-full bg-black/40 border border-slate-700/30 rounded-2xl py-3 pl-12 pr-4 text-white font-bold placeholder:text-slate-600 focus:border-indigo-500 transition-all outline-none"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                    </div>
                    <div className="flex gap-2">
                        {['Todos', 'Presente', 'Falta', 'Franco'].map(s => (
                            <button
                                key={s}
                                onClick={() => setSelectedStatus(s as any)}
                                className={`px-4 py-2.5 rounded-xl text-[10px] font-black uppercase border transition-all ${selectedStatus === s ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-800 border-white/5 text-slate-500 hover:text-white'}`}
                            >
                                {s}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Sheet Table */}
                <div className="flex-1 bg-slate-900/60 backdrop-blur-xl border border-white/5 rounded-[2.5rem] overflow-hidden shadow-2xl flex flex-col">
                    <div className="overflow-auto scrollbar-thin scrollbar-thumb-indigo-500/20 scrollbar-track-transparent">
                        <table className="w-full border-collapse text-left">
                            <thead className="bg-black/60 sticky top-0 z-20">
                                <tr>
                                    <th className="px-6 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 border-b border-white/5">Agente</th>
                                    <th className="px-6 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 border-b border-white/5">Fecha</th>
                                    <th className="px-6 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 border-b border-white/5 text-center">Entrada</th>
                                    <th className="px-6 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 border-b border-white/5 text-center">Salida</th>
                                    <th className="px-6 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 border-b border-white/5 text-center">Horas</th>
                                    <th className="px-6 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 border-b border-white/5 text-center">Valor H.</th>
                                    <th className="px-6 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 border-b border-white/5 text-center">Pago Día</th>
                                    <th className="px-6 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 border-b border-white/5">Estatus</th>
                                    <th className="px-6 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 border-b border-white/5">Notas</th>
                                    <th className="px-6 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 border-b border-white/5 text-right">Acciones</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-white/5">
                                {flatData.map((row, index) => {
                                    // Separador por DIA
                                    const isNewDay = index === 0 || flatData[index - 1].day !== row.day;

                                    return (
                                        <React.Fragment key={`${row.empId}-${row.day}`}>
                                            {isNewDay && (
                                                <tr className="bg-slate-950/80 border-y border-indigo-500/30">
                                                    <td colSpan={10} className="py-3 px-6">
                                                        <div className="flex items-center gap-3">
                                                            <div className="p-1.5 bg-indigo-500 rounded text-white"><Clock size={14} /></div>
                                                            <span className="text-white font-black text-xs uppercase tracking-[0.2em]">
                                                                {row.date}
                                                            </span>
                                                            <div className="h-px bg-indigo-500/30 flex-1"></div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            )}
                                            <tr
                                                className="group hover:bg-white/[0.03] transition-colors cursor-pointer"
                                                onClick={() => handleOpenDetail(row.empId, row.day)}
                                            >
                                                <td className="px-6 py-4">
                                                    <div className="flex flex-col">
                                                        <span className="text-white font-black text-sm tracking-tight">{row.name}</span>
                                                        <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded w-fit mt-1 shadow-lg ${row.group === 'Barco' ? 'bg-yellow-500/10 text-yellow-500 border border-yellow-500/20' :
                                                            row.group === 'Franquero' ? 'bg-cyan-400/10 text-cyan-400 border border-cyan-400/20 shadow-[0_0_10px_rgba(34,211,238,0.2)]' :
                                                                'bg-pink-500/10 text-pink-500 border border-pink-500/20'
                                                            }`}>{row.group}</span>
                                                    </div>
                                                </td>
                                                <td className="px-6 py-4 font-mono text-xs text-slate-400">{row.date}</td>
                                                <td className="px-6 py-4 text-center font-mono text-white text-xs">{row.entrada !== '0' ? row.entrada : '-'}</td>
                                                <td className="px-6 py-4 text-center font-mono text-white text-xs">{row.salida !== '0' ? row.salida : '-'}</td>
                                                <td className="px-6 py-4 text-center">
                                                    <span className={`font-mono font-bold text-sm ${parseFloat(row.horas) > 0 ? 'text-indigo-400' : 'text-slate-600'}`}>
                                                        {row.horas}
                                                    </span>
                                                </td>
                                                <td className="px-6 py-4 text-center font-mono text-[10px] text-slate-500">${row.rate}</td>
                                                <td className="px-6 py-4 text-center">
                                                    <span className={`font-mono font-bold text-sm ${parseFloat(row.pay) > 0 ? 'text-emerald-400' : 'text-slate-600'}`}>
                                                        ${row.pay}
                                                    </span>
                                                </td>
                                                <td className="px-6 py-4">
                                                    <span className={`inline-flex items-center gap-1.5 px-2 py-1 rounded text-[9px] font-black uppercase tracking-widest border ${row.status === 'Presente' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-rose-500/10 text-rose-500 border-rose-500/20'}`}>
                                                        <div className={`w-1.5 h-1.5 rounded-full ${row.status === 'Presente' ? 'bg-emerald-400 shadow-[0_0_5px_#34d399]' : 'bg-rose-500'}`}></div>
                                                        {row.status}
                                                    </span>
                                                </td>
                                                <td className="px-6 py-4">
                                                    <span className="text-[10px] text-slate-500 italic max-w-[150px] truncate block">{row.notas || '-'}</span>
                                                </td>
                                                <td className="px-6 py-4 text-right">
                                                    <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                        <button onClick={(e) => { e.stopPropagation(); handleOpenDetail(row.empId, row.day); }} className="p-2 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 rounded-xl transition-all"><Edit3 size={14} /></button>
                                                        <button onClick={(e) => handleDeleteEntry(e, row.empId, row.day)} className="p-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 rounded-xl transition-all"><Trash2 size={14} /></button>
                                                    </div>
                                                </td>
                                            </tr>
                                        </React.Fragment>
                                    );
                                })}
                            </tbody>

                        </table>
                    </div>
                </div>
            </main>

            {/* EDIT DETAIL MODAL (Matching User Image 0) */}
            {activeModal === 'detail' && activeEntry && (
                <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-300">
                    <div className="bg-[#0f172a] border border-indigo-500/30 w-full max-w-md rounded-[3rem] p-10 shadow-3xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-6 opacity-5 text-indigo-500 pointer-events-none"><Activity size={100} /></div>

                        <div className="flex justify-between items-start mb-8 relative z-10">
                            <div>
                                <h3 className="text-white font-black text-3xl tracking-tighter uppercase italic leading-none">Registro de Asistencia</h3>
                                {activeEntry.isNew ? (
                                    <div className="mt-4 space-y-2">
                                        <div className="flex gap-2">
                                            <select
                                                value={activeEntry.empId}
                                                onChange={(e) => setActiveEntry({ ...activeEntry, empId: e.target.value })}
                                                className="bg-indigo-500/10 border border-indigo-500/20 rounded-xl px-3 py-2 text-[10px] font-black uppercase text-indigo-300 outline-none focus:border-indigo-500 w-full"
                                            >
                                                {employees.map(e => <option key={e.id} value={e.id} className="bg-[#0f172a] text-white font-bold">{e.name}</option>)}
                                            </select>
                                            <select
                                                value={activeEntry.day}
                                                onChange={(e) => setActiveEntry({ ...activeEntry, day: Number(e.target.value) })}
                                                className="bg-indigo-500/10 border border-indigo-500/20 rounded-xl px-3 py-2 text-[10px] font-black uppercase text-indigo-300 outline-none focus:border-indigo-500 w-32 text-center"
                                            >
                                                {days.map(d => (
                                                    <option key={d} value={d} className="bg-[#0f172a] text-white font-bold">
                                                        {d.toString().padStart(2, '0')}/{(selectedMonth + 1).toString().padStart(2, '0')}/{selectedYear}
                                                    </option>
                                                ))}
                                            </select>
                                        </div>
                                    </div>
                                ) : (
                                    <p className="text-indigo-400 text-xs font-black uppercase tracking-[0.2em] mt-3 bg-indigo-500/10 w-fit px-3 py-1 rounded-full border border-indigo-500/20">
                                        Día {activeEntry.day} • {employees.find(e => e.id === activeEntry.empId)?.name}
                                    </p>
                                )}
                            </div>
                            <button onClick={() => setActiveModal(null)} className="p-3 bg-slate-800 hover:bg-slate-700 rounded-full text-slate-400 transition-all hover:rotate-90 duration-300">
                                <X size={24} />
                            </button>
                        </div>

                        <div className="space-y-6">
                            <div className="grid grid-cols-2 gap-6">
                                <div className="space-y-2">
                                    <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest ml-1">ENTRADA</label>
                                    <input
                                        type="text"
                                        placeholder="HH:MM"
                                        className="w-full bg-[#080d1a] border border-white/5 rounded-3xl py-5 px-6 text-white font-mono text-xl focus:border-indigo-500 transition-all outline-none shadow-inner text-center"
                                        value={detailForm.entrada}
                                        onChange={(e) => setDetailForm({ ...detailForm, entrada: e.target.value })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest ml-1">SALIDA</label>
                                    <input
                                        type="text"
                                        placeholder="HH:MM"
                                        className="w-full bg-[#080d1a] border border-white/5 rounded-3xl py-5 px-6 text-white font-mono text-xl focus:border-indigo-500 transition-all outline-none shadow-inner text-center"
                                        value={detailForm.salida}
                                        onChange={(e) => setDetailForm({ ...detailForm, salida: e.target.value })}
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest ml-1">TOTAL HORAS</label>
                                <div className="relative group">
                                    <input
                                        type="text"
                                        placeholder="0.0"
                                        className="w-full bg-[#030712] border border-emerald-500/20 rounded-[2rem] py-8 px-6 text-emerald-400 font-mono text-5xl font-black focus:border-emerald-500 transition-all outline-none text-center shadow-[0_0_50px_rgba(16,185,129,0.05)]"
                                        value={detailForm.horas}
                                        onChange={(e) => setDetailForm({ ...detailForm, horas: e.target.value })}
                                    />
                                    <div className="absolute right-8 top-1/2 -translate-y-1/2 text-emerald-500/20 font-black text-2xl">HRS</div>
                                </div>
                            </div>

                            <div className="grid grid-cols-3 gap-3">
                                {['Presente', 'Falta', 'Franco'].map(st => (
                                    <button
                                        key={st}
                                        onClick={() => setDetailForm({ ...detailForm, estatus: st })}
                                        className={`py-3 rounded-2xl text-[10px] font-black uppercase border transition-all ${detailForm.estatus === st ? 'bg-white/10 border-indigo-500 text-white' : 'bg-black/20 border-white/5 text-slate-600 hover:text-slate-400'}`}
                                    >
                                        {st}
                                    </button>
                                ))}
                            </div>

                            <div className="space-y-2">
                                <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest ml-1">NOTAS / OBSERVACIONES</label>
                                <textarea
                                    placeholder="Detalles adicionales..."
                                    className="w-full bg-[#080d1a] border border-white/5 rounded-3xl py-4 px-6 text-white text-sm focus:border-indigo-500 transition-all outline-none shadow-inner resize-none h-24"
                                    value={detailForm.notas}
                                    onChange={(e) => setDetailForm({ ...detailForm, notas: e.target.value })}
                                />
                            </div>

                            <button
                                onClick={handleSaveDetail}
                                className="w-full bg-[#4f46e5] hover:bg-[#4338ca] text-white font-black py-6 rounded-[2rem] shadow-2xl shadow-indigo-500/20 transition-all flex items-center justify-center gap-3 active:scale-[0.98] mt-4"
                            >
                                <Save size={24} /> <span className="text-xl tracking-tight">GUARDAR REGISTRO</span>
                            </button>

                            <p className="text-[9px] text-slate-600 italic text-center uppercase tracking-widest">Automatic status: {parseFloat(detailForm.horas) > 0 ? 'Presente' : 'Falta'}</p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default NominaModule;
