import React, { useState, useEffect } from 'react';
import { supabase } from './lib/supabase';
import { DollarSign, LogOut, Save, Trash2, Edit2, X, FileText, Calendar, RefreshCw, ShieldAlert } from 'lucide-react';

interface MobileProps {
    user: { email: string; role: 'fijo_barco' | 'fijo_cueva' | 'franquero'; name: string };
    onLogout: () => void;
    onNavigateToRestriccion?: () => void;
}

const MobileOperative: React.FC<MobileProps> = ({ user, onLogout, onNavigateToRestriccion }) => {
    // --- ESTADOS ---
    const [view, setView] = useState<'registro' | 'nomina'>('registro');
    const [bando, setBando] = useState<'Barco' | 'Cueva'>(
        user.role === 'fijo_barco' ? 'Barco' : user.role === 'fijo_cueva' ? 'Cueva' : 'Barco'
    );
    const [monto, setMonto] = useState('');

    // DATA HANDLING (Mover la funcion arriba para usarla en init state)
    const getOperationalDate = () => {
        const now = new Date();
        if (now.getHours() < 3) {
            now.setDate(now.getDate() - 1);
        }
        return now.toISOString().split('T')[0];
    };

    const [fecha, setFecha] = useState(getOperationalDate()); // Default: Turno actual
    const [registros, setRegistros] = useState<any[]>([]);
    const [historialDias, setHistorialDias] = useState<any>({}); // Grouped history
    const [loading, setLoading] = useState(false);

    // Estado para edición
    const [editingId, setEditingId] = useState<string | null>(null);

    // --- ESTADOS DE NÓMINA ---
    const [payrollData, setPayrollData] = useState<any>(null);
    const [loadingPayroll, setLoadingPayroll] = useState(false);
    const [currentFortnight, setCurrentFortnight] = useState(1);
    const [comprobanteUrl, setComprobanteUrl] = useState<string | null>(null);

    useEffect(() => {
        loadDailyRecords();
        loadPayrollData();
        loadProfile();
        loadHistorySummary();
    }, []);

    // Add useEffect to reload when 'fecha' changes
    useEffect(() => {
        loadDailyRecords();
    }, [fecha]);

    const loadProfile = async () => {
        const { data } = await supabase
            .from('perfiles_empleados')
            .select('comprobante_url')
            .eq('user_email', user.email)
            .single();
        if (data) setComprobanteUrl(data.comprobante_url);
    };

    // --- LOGICA REGISTROS ---
    const loadDailyRecords = async () => {
        const { data } = await supabase
            .from('registros_operativos')
            .select('*')
            .eq('user_email', user.email)
            .eq('fecha_operacion', fecha)
            .order('created_at', { ascending: false });

        if (data) setRegistros(data);
    };

    const loadHistorySummary = async () => {
        const { data } = await supabase
            .from('registros_operativos')
            .select('fecha_operacion, monto_apuesta')
            .eq('user_email', user.email)
            .order('fecha_operacion', { ascending: false });

        if (data) {
            const months: any = {};
            data.forEach((r: any) => {
                const dateObj = new Date(r.fecha_operacion + 'T12:00:00'); // Evitar problemas de timezone
                const monthName = dateObj.toLocaleString('es-ES', { month: 'long' }).toUpperCase();
                const year = dateObj.getFullYear();
                const day = dateObj.getDate();
                const key = `${monthName} ${year}`;
                const fortnight = day <= 15 ? 'Q1 (01-15)' : 'Q2 (16-31/30)';

                if (!months[key]) months[key] = {};
                if (!months[key][fortnight]) months[key][fortnight] = { total: 0, days: [] };

                months[key][fortnight].total += r.monto_apuesta;
                if (!months[key][fortnight].days.includes(r.fecha_operacion)) {
                    months[key][fortnight].days.push(r.fecha_operacion);
                }
            });
            setHistorialDias(months);
        }
    };

    const handleGuardar = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!monto) return;

        setLoading(true);
        // FORCE POSITIVE AND ROUND
        const montoNum = Math.abs(parseFloat(monto) || 0);

        // Calculo individual para compatibilidad
        const gananciaIndividual = (montoNum * 2) * 0.08;

        // FIXED TIME FORMAT: HH:MM:SS (24h)
        const timeString = new Date().toTimeString().split(' ')[0];
        // USAMOS LA FECHA SELECCIONADA POR EL USUARIO (o la calculada por defecto)
        const opDate = fecha;

        if (editingId) {
            // UPDATE
            const { error } = await supabase.from('registros_operativos').update({
                monto_apuesta: montoNum,
                ganancia_calculada: gananciaIndividual,
                bando: bando,
                fecha_operacion: opDate // Permitir cambiar fecha al editar
            }).eq('id', editingId);

            if (!error) {
                setMonto('');
                setEditingId(null);
                setFecha(getOperationalDate()); // Reset a hoy
                loadDailyRecords();
            } else {
                alert('Error al actualizar: ' + error.message);
            }
        } else {
            // INSERT
            const { error } = await supabase.from('registros_operativos').insert({
                user_email: user.email,
                user_role: user.role,
                bando: bando,
                mesa: 'General',
                monto_apuesta: montoNum,
                ganancia_calculada: gananciaIndividual,
                hora_registro: timeString, // Uses standard format now
                fecha_operacion: opDate
            });

            if (!error) {
                setMonto('');
                loadDailyRecords();
                loadHistorySummary();
            } else {
                alert('Error al guardar: ' + error.message);
            }
        }
        setLoading(false);
    };

    const handleEdit = (reg: any) => {
        setMonto(reg.monto_apuesta.toString());
        setFecha(reg.fecha_operacion);
        setBando(reg.bando); // Sincronizar el bando al editar
        setEditingId(reg.id);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const handleDelete = async (id: string) => {
        if (!confirm('¿Borrar este registro?')) return;
        const { error } = await supabase.from('registros_operativos').delete().eq('id', id);
        if (!error) {
            loadDailyRecords();
            loadHistorySummary();
        }
    };

    const cancelEdit = () => {
        setEditingId(null);
        setMonto('');
        setFecha(getOperationalDate());
    };

    // --- LOGICA NÓMINA (Sync with Admin Backup) ---
    const loadPayrollData = async () => {
        setLoadingPayroll(true);
        // Leemos el backup ID=1 que guarda el Dashboard
        const { data } = await supabase.from('app_backups').select('content').eq('id', 1).single();
        if (data && data.content) {
            setPayrollData(data.content);
        } else {
            // Si no hay backup, quizás no se ha guardado nunca desde el Dashboard
            console.warn("No se encontró backup ID=1 en app_backups");
        }
        setLoadingPayroll(false);
    };

    const getEmployeeData = () => {
        if (!payrollData || !payrollData.employees) return null;
        // Buscamos coincidencia por nombre (El admin debe poner el mismo nombre que tienes aqui)
        return payrollData.employees.find((e: any) => e.name.trim().toLowerCase() === user.name.trim().toLowerCase());
    };

    const getShiftValue = (empId: number, day: number) => {
        if (!payrollData || !payrollData.shifts) return '';
        // Fix: Access nested object structure from Dashboard { empId: { day: value } }
        return payrollData.shifts[empId]?.[day] || '';
    };

    // --- CALCULOS GLOBALES ---
    const totalApuestas = registros.reduce((acc, curr) => acc + curr.monto_apuesta, 0);
    // LOGICA PEDIDA: ((TotalApuestas * 2) * 0.08)
    const totalGananciaTurno = (totalApuestas * 2) * 0.08;

    const matchedEmployee = getEmployeeData();
    const daysRange = currentFortnight === 1
        ? [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
        : [16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31];

    // Helper para parsear horas
    const parseHours = (val: string | number) => {
        if (!val) return 0;
        if (typeof val === 'number') return val;
        // Fix: Replace comma with dot for decimal handling (4,5 -> 4.5)
        const sVal = val.toString().replace(',', '.');
        if (sVal.includes(':')) {
            const [h, m] = sVal.split(':').map(Number);
            return h + (m / 60);
        }
        return parseFloat(sVal) || 0;
    };

    let totalHours = 0;
    let totalPay = 0;
    if (matchedEmployee) {
        daysRange.forEach(day => {
            const val = getShiftValue(matchedEmployee.id, day);
            if (val && !['F', 'A', 'L'].includes(val)) {
                totalHours += parseHours(val);
            }
        });
        totalPay = (totalHours / 9) * 9.6;
    }

    return (
        <div className="min-h-screen bg-black font-sans pb-24 relative overflow-hidden selection:bg-cyan-500/30">
            {/* --- ULTRA-FUTURISTIC BACKGROUND (AURORA VOID) --- */}
            <div className="fixed inset-0 z-0 pointer-events-none">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#1a1b26] via-[#000000] to-[#000000]"></div>
                <div className="absolute top-[-10%] left-[-10%] w-[100vw] h-[100vw] bg-indigo-600/10 rounded-full blur-[120px] animate-pulse mix-blend-screen opacity-50"></div>
                <div className="absolute bottom-[-10%] right-[-10%] w-[100vw] h-[100vw] bg-cyan-600/10 rounded-full blur-[120px] animate-pulse delay-1000 mix-blend-screen opacity-50"></div>
                <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_at_center,black_40%,transparent_100%)]"></div>
            </div>

            {/* HEADER */}
            <header className="relative z-50 bg-slate-900 border-b border-slate-800 p-4 sticky top-0 shadow-lg">
                <div className="flex justify-between items-center">
                    <div className="flex flex-col">
                        <div className="flex items-center gap-2">
                            <img src="/logo.png" alt="Logo" className="h-8 w-auto" />
                            <span className="text-[10px] bg-emerald-500/10 text-emerald-500 px-2 py-0.5 rounded border border-emerald-500/20 font-black">V2.6</span>
                        </div>
                        <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">
                            {user.name} • {bando}
                        </span>
                    </div>
                    <div className="flex gap-2">
                        <button
                            onClick={() => {
                                loadDailyRecords();
                                loadPayrollData();
                                loadHistorySummary();
                            }}
                            className="p-2 bg-slate-800 text-slate-400 rounded-lg active:scale-90 transition-all"
                            title="Refrescar Datos"
                        >
                            <RefreshCw size={20} className={loading || loadingPayroll ? 'animate-spin' : ''} />
                        </button>
                        <button onClick={onLogout} className="p-2 bg-red-500/10 text-red-500 rounded-lg active:scale-90 transition-all">
                            <LogOut size={20} />
                        </button>
                    </div>
                </div>

                {/* INDICADOR DE FECHA OPERATIVA - ULTRA LLAMATIVO FUCSIA */}
                <div className="mt-4 flex flex-col md:flex-row items-center justify-between bg-black/60 p-5 rounded-[2rem] border-2 border-fuchsia-500/50 shadow-[0_0_30px_rgba(217,70,239,0.2)] gap-4">
                    <div className="flex items-center gap-4 w-full md:w-auto">
                        <div className="w-4 h-4 rounded-full bg-fuchsia-500 animate-ping shadow-[0_0_20px_#d946ef]"></div>
                        <div className="relative">
                            <div className="absolute -inset-1 bg-fuchsia-500 blur opacity-25 rounded-full"></div>
                            <p className="text-[11px] text-fuchsia-400 font-black uppercase tracking-[0.2em] leading-none">Jornada Operativa</p>
                            <p className="text-xl font-mono font-black text-white mt-1 drop-shadow-[0_0_8px_rgba(255,255,255,0.3)]">{fecha}</p>
                        </div>
                    </div>

                    <div className="flex flex-col items-center md:items-end gap-2 w-full md:w-auto">
                        <span className="text-[11px] text-fuchsia-300 font-black uppercase tracking-widest animate-bounce flex items-center gap-2 bg-fuchsia-500/10 px-3 py-1 rounded-full border border-fuchsia-500/20">
                            <ShieldAlert size={14} className="text-fuchsia-400" /> Verifica la fecha que cargaras
                        </span>
                        <div className="relative w-full md:w-56 group">
                            {/* Icono de calendario llamativo superpuesto */}
                            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-fuchsia-400 z-10 pointer-events-none group-hover:scale-110 transition-transform">
                                <Calendar size={24} className="drop-shadow-[0_0_10px_rgba(217,70,239,0.8)]" strokeWidth={3} />
                            </div>
                            <input
                                type="date"
                                value={fecha}
                                onChange={(e) => setFecha(e.target.value)}
                                className="w-full bg-slate-900 text-white text-lg font-black pl-14 pr-4 py-5 rounded-2xl border-4 border-fuchsia-600 outline-none focus:border-fuchsia-400 focus:ring-8 focus:ring-fuchsia-500/30 transition-all cursor-pointer shadow-[0_0_20px_rgba(217,70,239,0.4)] appearance-none"
                            />
                            {/* Brillo neon extra en el borde del input */}
                            <div className="absolute inset-0 rounded-2xl border-2 border-fuchsia-400/50 animate-pulse pointer-events-none"></div>
                        </div>
                    </div>
                </div>
            </header>

            {/* CONTENIDO PRINCIPAL */}
            <div className="px-4 mt-6 relative z-10">
                {view === 'registro' && (
                    <div className="space-y-6">
                        {/* SELECTOR DE BANDO */}
                        <div className="bg-slate-900/60 backdrop-blur-xl rounded-2xl p-1.5 flex border border-white/10 shadow-xl mb-4">
                            <button onClick={() => setBando('Barco')} className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all ${bando === 'Barco' ? 'bg-yellow-500 text-slate-950 shadow-[0_0_15px_rgba(234,179,8,0.4)]' : 'text-slate-500 hover:text-slate-300'}`}>EL BARCO</button>
                            <button onClick={() => setBando('Cueva')} className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all ${bando === 'Cueva' ? 'bg-pink-600 text-white shadow-[0_0_15px_rgba(236,72,153,0.4)]' : 'text-slate-500 hover:text-slate-300'}`}>LA CUEVA</button>
                        </div>

                        {/* FORMULARIO */}
                        <div className={`bg-slate-900/40 backdrop-blur-2xl rounded-[2.5rem] p-8 border border-white/10 shadow-2xl relative overflow-hidden transition-all duration-500 ${editingId ? 'ring-2 ring-cyan-400 scale-[1.02]' : ''}`}>
                            <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-cyan-500 to-transparent opacity-20 animate-pulse"></div>
                            <h2 className="text-white font-bold text-lg mb-6 flex items-center justify-between">
                                <span className="flex items-center gap-3">
                                    <div className={`p-2.5 rounded-xl transition-all shadow-lg ${editingId ? 'bg-cyan-500 text-white shadow-cyan-500/20' : 'bg-white/5 text-cyan-400 border border-white/10'}`}>
                                        <RefreshCw size={20} className={loading ? 'animate-spin' : ''} />
                                    </div>
                                    <span className="tracking-tight">{editingId ? 'EDITAR APUESTA' : 'NUEVA APUESTA'}</span>
                                </span>
                                {editingId && <button onClick={cancelEdit} className="text-slate-400 hover:text-white bg-white/5 p-2 rounded-full border border-white/10"><X size={20} /></button>}
                            </h2>

                            <form onSubmit={handleGuardar} className="space-y-6">
                                <div className="bg-black/40 rounded-2xl p-4 flex items-center justify-between border border-white/5 group focus-within:border-cyan-500/30 transition-all shadow-inner">
                                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.1em] flex items-center gap-2">
                                        <Calendar size={14} className="text-cyan-400" /> FECHA TURNO
                                    </span>
                                    <input type="date" required className="bg-transparent text-white font-bold text-sm outline-none text-right [color-scheme:dark] flex-1 ml-4" value={fecha} onChange={e => setFecha(e.target.value)} />
                                </div>

                                <div className="relative group">
                                    <div className="absolute left-6 top-1/2 -translate-y-1/2 text-cyan-400 font-bold text-2xl drop-shadow-[0_0_8px_rgba(34,211,238,0.4)] transition-all group-focus-within:scale-125">$</div>
                                    <input type="number" step="any" required className="w-full bg-black/40 border-none rounded-[2rem] py-10 pl-14 pr-6 text-white font-mono font-bold text-5xl text-center focus:ring-0 transition-all placeholder:text-slate-800 outline-none shadow-inner" placeholder="0" value={monto} onChange={e => setMonto(e.target.value)} />
                                </div>

                                <button disabled={loading} className={`w-full font-bold py-5 rounded-2xl text-lg shadow-2xl active:scale-95 transition-all flex justify-center items-center gap-3 tracking-widest ${editingId ? 'bg-cyan-500 text-white shadow-cyan-500/20' : 'bg-white text-black hover:bg-cyan-400 hover:text-white shadow-white/5'}`}>
                                    {loading ? 'MODULANDO...' : editingId ? 'ACTUALIZAR' : 'REGISTRAR'}
                                </button>
                            </form>
                        </div>

                        {/* TOTALES DEL TURNO */}
                        <div className="bg-slate-900/60 backdrop-blur-xl rounded-[2rem] p-8 text-white shadow-2xl border border-white/10 relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-[60px] -mr-10 -mt-10"></div>
                            <div className="relative z-10 grid grid-cols-2 gap-y-8 gap-x-6">
                                <div>
                                    <div className="text-[10px] uppercase font-bold tracking-[0.2em] mb-2 text-slate-500">Total Apostado</div>
                                    <div className="text-3xl font-mono font-bold text-white tracking-tighter">${totalApuestas}</div>
                                </div>
                                <div className="text-right">
                                    <div className="text-[10px] uppercase font-bold tracking-[0.2em] mb-2 text-pink-400/70">Nº Apuestas</div>
                                    <div className="text-3xl font-mono font-bold text-pink-400 drop-shadow-[0_0_8px_rgba(236,72,153,0.3)]">{registros.length}</div>
                                </div>
                                <div className="col-span-2 pt-4 border-t border-white/5">
                                    <div className="text-[10px] uppercase font-bold tracking-[0.2em] mb-2 text-cyan-400/70 text-center">Tu Ganancia Turno (8%)</div>
                                    <div className="text-5xl font-mono font-bold text-[#ffd700] drop-shadow-[0_0_15px_rgba(255,215,0,0.4)] text-center">${totalGananciaTurno.toFixed(2)}</div>
                                    <div className="text-[10px] text-slate-600 mt-2 font-mono tracking-tight italic text-center">Calculado sobre: (${totalApuestas} x 2)</div>
                                </div>
                            </div>
                        </div>

                        {/* DETALLE DE APUESTAS */}
                        <div>
                            <h3 className="text-slate-400 font-bold uppercase tracking-[0.2em] text-[10px] mb-4 ml-4 flex justify-between items-center opacity-80">
                                <span className="flex items-center gap-2">
                                    <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse"></div>
                                    DETALLE APUESTAS
                                </span>
                                <span className="bg-white/5 px-2.5 py-1 rounded-full border border-white/10 text-[9px] font-mono">{registros.length} REGS.</span>
                            </h3>
                            <div className="space-y-3 pb-4">
                                {registros.map((reg) => (
                                    <div key={reg.id} className="group bg-slate-900/40 backdrop-blur-md border border-white/5 p-4 flex justify-between items-center rounded-2xl hover:border-cyan-500/30 transition-all">
                                        <div className="flex items-center gap-4">
                                            <div className="bg-black/40 p-3 rounded-xl border border-white/5 text-cyan-400 group-hover:scale-110 transition-transform">
                                                <DollarSign size={18} />
                                            </div>
                                            <div>
                                                <div className="text-white font-bold font-mono text-xl tracking-tight">${reg.monto_apuesta}</div>
                                                <div className="text-slate-500 text-[10px] font-mono mt-0.5">{reg.hora_registro}</div>
                                            </div>
                                        </div>
                                        <div className="flex gap-2">
                                            <button onClick={() => handleEdit(reg)} className="p-3 text-slate-400 hover:text-cyan-400 bg-white/5 rounded-xl border border-white/5 hover:border-cyan-500/20 active:scale-90 transition-all"><Edit2 size={14} /></button>
                                            <button onClick={() => handleDelete(reg.id)} className="p-3 text-slate-400 hover:text-rose-400 bg-white/5 rounded-xl border border-white/5 hover:border-rose-500/20 active:scale-90 transition-all"><Trash2 size={14} /></button>
                                        </div>
                                    </div>
                                ))}
                                {registros.length === 0 && (
                                    <div className="p-12 text-center bg-slate-900/20 rounded-[2rem] border border-white/5 border-dashed">
                                        <div className="text-slate-600 font-bold text-sm uppercase tracking-widest italic opacity-50">Sin transmisiones hoy</div>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* HISTORIAL POR QUINCENAS */}
                        <div className="pb-28">
                            <h3 className="text-slate-400 font-bold uppercase tracking-[0.2em] text-[10px] mb-4 ml-4 flex items-center gap-2 opacity-80">
                                <FileText size={14} className="text-indigo-400" /> HISTORIAL POR QUINCENAS
                            </h3>
                            <div className="space-y-6">
                                {Object.entries(historialDias).map(([monthKey, fortnights]: [string, any]) => (
                                    <div key={monthKey} className="space-y-3">
                                        <div className="text-indigo-400 font-black text-[11px] tracking-[0.3em] ml-4 pt-2 border-t border-white/5">{monthKey}</div>
                                        {Object.entries(fortnights).map(([qKey, data]: [string, any]) => (
                                            <div key={qKey} className="bg-slate-900/40 border border-white/5 rounded-2xl overflow-hidden shadow-xl">
                                                <div className="p-4 bg-white/5 flex justify-between items-center border-b border-white/5">
                                                    <span className="text-xs font-bold text-slate-300">{qKey}</span>
                                                    <span className="text-sm font-black text-white font-mono">${data.total.toFixed(2)}</span>
                                                </div>
                                                <div className="p-2 grid grid-cols-3 gap-2">
                                                    {data.days.sort().reverse().map((d: string) => (
                                                        <button key={d} onClick={() => { setFecha(d); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className={`py-2 rounded-lg text-[10px] font-bold border transition-all ${fecha === d ? 'bg-cyan-500 text-white border-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.3)]' : 'bg-black/20 text-slate-500 border-white/5 hover:border-white/10'}`}>
                                                            DÍA {d.split('-')[2]}
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                ))}
                                {Object.keys(historialDias).length === 0 && (
                                    <div className="p-8 text-center text-slate-600 text-xs italic">No hay historial disponible</div>
                                )}
                            </div>
                        </div>
                    </div>
                )}

                {view === 'nomina' && (
                    <div className="space-y-6 animate-in slide-in-from-right duration-500 relative z-10">
                        <div className="flex justify-between items-center mb-2 px-2">
                            <h2 className="text-white font-bold text-lg flex items-center gap-3">
                                <div className="p-2 bg-indigo-500/20 rounded-lg border border-indigo-500/30 text-indigo-400">
                                    <Calendar size={20} />
                                </div>
                                <span className="tracking-tight capitalize">Mi Nómina</span>
                            </h2>
                            <button onClick={loadPayrollData} className="p-3 bg-slate-900/60 text-indigo-400 rounded-full border border-white/10 hover:bg-indigo-500/20 hover:text-white transition-all active:rotate-180 duration-500" title="Recargar"><RefreshCw size={18} className={loadingPayroll ? 'animate-spin' : ''} /></button>
                        </div>

                        {/* CONTROLES DE QUINCENA */}
                        <div className="flex bg-slate-950/60 backdrop-blur-xl p-1.5 rounded-2xl border border-white/10 shadow-2xl">
                            <button onClick={() => setCurrentFortnight(1)} className={`flex-1 py-3 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${currentFortnight === 1 ? 'bg-indigo-600 text-white shadow-[0_0_15px_rgba(79,70,229,0.4)]' : 'text-slate-500 hover:text-slate-300'}`}>01 - 15 ENE</button>
                            <button onClick={() => setCurrentFortnight(2)} className={`flex-1 py-3 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${currentFortnight === 2 ? 'bg-indigo-600 text-white shadow-[0_0_15px_rgba(79,70,229,0.4)]' : 'text-slate-500 hover:text-slate-300'}`}>16 - 31 ENE</button>
                        </div>

                        {matchedEmployee ? (
                            <div className="space-y-6 font-sans">
                                <div className="bg-slate-900/40 backdrop-blur-2xl rounded-[2rem] overflow-hidden border border-white/10 shadow-2xl">
                                    <div className="p-5 bg-white/5 border-b border-white/5 flex justify-between items-center tracking-tight">
                                        <span className="font-bold text-white uppercase text-xs tracking-[0.1em]">{matchedEmployee.name}</span>
                                        <span className={`text-[9px] px-2.5 py-1 rounded-full uppercase font-bold tracking-widest border shadow-lg ${matchedEmployee.status === 'Activo' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-rose-500/10 text-rose-400 border-rose-500/30'}`}>{matchedEmployee.status}</span>
                                    </div>
                                    <div className="overflow-x-auto">
                                        <table className="w-full text-sm text-left border-collapse">
                                            <thead className="bg-black/20 text-slate-500 text-[9px] uppercase font-bold tracking-[0.2em]">
                                                <tr>
                                                    <th className="p-4 text-center">Día</th>
                                                    <th className="p-4 text-center">Horas</th>
                                                    <th className="p-4 text-center">Subtotal</th>
                                                </tr>
                                            </thead>
                                            <tbody className="divide-y divide-white/5">
                                                {daysRange.map(day => {
                                                    const val = getShiftValue(matchedEmployee.id, day);
                                                    if (!val || val === '.') return null;
                                                    let displayVal = val;
                                                    let rowClass = "text-slate-300";
                                                    if (val === 'F') { displayVal = 'FALTA'; rowClass = "text-rose-500 font-bold"; }
                                                    else if (val === 'L') { displayVal = 'LIBRE'; rowClass = "text-indigo-400 font-bold"; }
                                                    else if (val === 'A') { displayVal = 'AUSENTE'; rowClass = "text-yellow-500 font-bold"; }
                                                    else { displayVal = val + ' HRS'; rowClass = "font-bold text-cyan-100 group-hover:text-cyan-400"; }
                                                    const dailyPay = (parseHours(displayVal.includes('HRS') ? val.toString() : '0') / 9) * 9.6;
                                                    return (
                                                        <tr key={day} className="group hover:bg-white/5 transition-colors">
                                                            <td className="p-4 text-center font-mono text-slate-500 text-[10px]">{day}</td>
                                                            <td className={`p-4 text-center ${rowClass} transition-colors`}>{displayVal}</td>
                                                            <td className="p-4 text-center font-mono text-cyan-400 font-bold text-xs ring-inset">{dailyPay > 0 ? `$${dailyPay.toFixed(2)}` : '-'}</td>
                                                        </tr>
                                                    );
                                                })}
                                            </tbody>
                                            <tfoot className="bg-black/40 font-bold border-t border-white/10 backdrop-blur-md">
                                                <tr>
                                                    <td className="p-5 text-center uppercase text-[9px] text-slate-500 tracking-[0.2em]">Resumen</td>
                                                    <td className="p-5 text-center text-indigo-400 font-mono italic">{totalHours} HRS</td>
                                                    <td className="p-5 text-center text-cyan-400 font-mono text-lg tracking-tighter drop-shadow-[0_0_8px_rgba(34,211,238,0.3)]">${totalPay.toFixed(2)}</td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                    {payrollData.meta && (
                                        <div className="p-3 text-center text-[8px] text-slate-700 bg-black/60 border-t border-white/5 uppercase tracking-[0.2em] font-medium">
                                            Sync: {new Date(payrollData.meta.timestamp).toLocaleTimeString()} • {new Date(payrollData.meta.timestamp).toLocaleDateString()}
                                        </div>
                                    )}
                                </div>
                                <div className="bg-slate-900/60 backdrop-blur-2xl rounded-[2rem] p-8 shadow-2xl border border-white/10 relative overflow-hidden animate-in slide-in-from-bottom duration-700 delay-200">
                                    <div className="absolute top-0 right-0 w-40 h-40 bg-indigo-500/10 rounded-full blur-[80px] -mr-10 -mt-10"></div>
                                    <h3 className="text-white font-bold text-base mb-6 flex items-center gap-3 relative z-10">
                                        <div className="p-2 bg-yellow-400/10 rounded-lg border border-yellow-400/30 text-yellow-400">
                                            <FileText size={18} />
                                        </div>
                                        <span className="tracking-tight uppercase text-xs font-bold tracking-[0.1em]">Comprobante Oficial</span>
                                    </h3>
                                    {comprobanteUrl ? (
                                        <div className="space-y-4 relative z-10 font-sans">
                                            <div className="bg-black/40 rounded-2xl p-5 border border-white/5 shadow-inner">
                                                <p className="text-slate-500 text-[10px] mb-4 leading-relaxed font-bold uppercase tracking-wider">Tu liquidación ha sido procesada:</p>
                                                <a href={comprobanteUrl} target="_blank" rel="noreferrer" className="block w-full bg-white text-black hover:bg-cyan-400 hover:text-white font-bold py-4 rounded-xl text-center text-xs transition-all shadow-[0_0_20px_rgba(255,255,255,0.1)] active:scale-95 flex items-center justify-center gap-3 transform hover:-translate-y-1">
                                                    <FileText size={18} /> DESCARGAR RECIBO PDF
                                                </a>
                                            </div>
                                            <p className="text-[9px] text-slate-700 text-center uppercase tracking-[0.4em] font-black opacity-40">Blockchain Verified</p>
                                        </div>
                                    ) : (
                                        <div className="bg-black/40 rounded-2xl p-10 border border-white/5 border-dashed text-center relative z-10 group hover:border-white/20 transition-colors">
                                            <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4 border border-white/5 shadow-inner">
                                                <FileText size={20} className="text-slate-800" />
                                            </div>
                                            <p className="text-slate-600 text-[10px] font-bold uppercase tracking-widest italic opacity-60">Pago en proceso</p>
                                            <p className="text-[10px] text-slate-700 mt-3 leading-relaxed font-medium">El comprobante aparecerá aquí <br />al confirmar la transferencia.</p>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ) : (
                            <div className="bg-slate-900/40 backdrop-blur-xl rounded-[2.5rem] p-10 text-center border border-white/10 border-dashed animate-pulse">
                                <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6 border border-white/5">
                                    <RefreshCw className="text-slate-700 animate-spin-slow" size={32} />
                                </div>
                                <div className="text-slate-400 text-sm font-bold uppercase tracking-widest mb-2">Sincronizando...</div>
                                <p className="text-xs text-slate-600 leading-relaxed font-medium">No se encontraron datos vinculados.<br />Nombre de usuario: <span className="text-cyan-400">"{user.name}"</span></p>
                            </div>
                        )}
                    </div>
                )}
            </div>

            {/* NAV BAR */}
            <div className="fixed bottom-0 left-0 w-full bg-black/80 backdrop-blur-2xl border-t border-white/10 p-3 flex justify-around items-center z-40 rounded-t-[30px] shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
                <button onClick={() => setView('registro')} className={`flex flex-col items-center gap-1.5 p-3 rounded-2xl transition-all w-24 relative ${view === 'registro' ? 'text-cyan-400' : 'text-slate-600'}`}>
                    {view === 'registro' && <div className="absolute inset-0 bg-cyan-500/10 rounded-2xl border border-cyan-500/20 shadow-[0_0_15px_rgba(6,182,212,0.15)] animate-in fade-in zoom-in-95 duration-300"></div>}
                    <Save size={24} className={`relative z-10 transition-transform ${view === 'registro' ? 'scale-110 drop-shadow-[0_0_8px_rgba(34,211,238,0.5)]' : ''}`} />
                    <span className="text-[10px] font-bold uppercase tracking-widest relative z-10">Registro</span>
                </button>
                <div className="w-[1px] h-8 bg-white/5"></div>
                <button onClick={() => setView('nomina')} className={`flex flex-col items-center gap-1.5 p-3 rounded-2xl transition-all w-24 relative ${view === 'nomina' ? 'text-indigo-400' : 'text-slate-600'}`}>
                    {view === 'nomina' && <div className="absolute inset-0 bg-indigo-500/10 rounded-2xl border border-indigo-500/20 shadow-[0_0_15px_rgba(79,70,229,0.15)] animate-in fade-in zoom-in-95 duration-300"></div>}
                    <FileText size={24} className={`relative z-10 transition-transform ${view === 'nomina' ? 'scale-110 drop-shadow-[0_0_8px_rgba(129,140,248,0.5)]' : ''}`} />
                    <span className="text-[10px] font-bold uppercase tracking-widest relative z-10">Nómina</span>
                </button>
                <div className="w-[1px] h-8 bg-white/5"></div>
                <button onClick={onNavigateToRestriccion} className="flex flex-col items-center gap-1.5 p-3 rounded-2xl transition-all w-24 relative text-rose-500/80 hover:text-rose-500">
                    <ShieldAlert size={24} className="animate-pulse" />
                    <span className="text-[10px] font-black uppercase tracking-widest">Bloqueos</span>
                </button>
            </div>
        </div>
    );
};

export default MobileOperative;
